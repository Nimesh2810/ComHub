<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <div class="container-fluid">
        <footer class="bg-black text-white pb-5 pt-4">
        <div class="container-fluid">
            <div class="row">

                <div class="col-12 text-md-start">
                    <div class="row text-sm-center text-md-start">
                        <div class="row">
                            <div class="col-12 col-md-3 col-lg-3 mx-auto mt-3">
                                <h5 class="text-uppercase text-warning mb-4">ComHub</h5>
                                <p>
                                    Here we are the ComHub&trade; to help you fulfill your
                                    desire by selling high quality Computers and Computer accessories .

                                </p>
                            </div>

                            <div class="col-12 col-md-4 col-lg-3 mx-auto mt-3">
                                <h5 class="text-uppercase text-warning mb-4">Services</h5>
                                <p>Computer Sell</p>
                                <p>Computer Part Sell</p>
                            </div>

                            <div class="col-12 col-md-4 col-lg-3 mx-auto mt-3">
                                <h5 class="text-uppercase text-warning mb-4">Information</h5>
                                <p><a href="#" class="text-decoration-none text-white">About ComHub</a></p>
                                <p><a href="PrivacyPolicy.php" class="text-decoration-none text-white">Privacy
                                        Policy</a></p>
                                <p><a href="#" class="text-decoration-none text-white">Terms & Conditions</a></p>
                            </div>

                            <div class="col-12 col-md-4 col-lg-3 mx-auto mt-3">
                                <h5 class="text-uppercase text-warning mb-4">Contacts</h5>
                                <p><i class="bi bi-house-fill"></i>Elibichchiya, Elibichchiya, Pannala, Sri Lanka.</p>
                                <p><i class="bi bi-envelope-at-fill"></i> nimeshsayuranga31@gmail.com</p>
                                <p><i class="bi bi-telephone-fill"></i> +9767 239 281</p>
                                <ul class="list-unstyled list-inline">
                                    <li class="list-inline-item">
                                        <a href="#" class="form-floting text-white">
                                            <i class="bi bi-facebook" style="font-size: 22px ;"></i>
                                        </a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="#" class="form-floting text-white">
                                            <i class="bi bi-whatsapp" style="font-size: 22px ;"></i>
                                        </a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="#" class="form-floting text-white">
                                            <i class="bi bi-telegram" style="font-size: 22px ;"></i>
                                        </a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="#" class="form-floting text-white">
                                            <i class="bi bi-youtube" style="font-size: 22px ;"></i>
                                        </a>
                                    </li>

                                </ul>

                            </div>

                            <hr class="mb-4" />
                        </div>
                    </div>
                </div>

            </div>

        </footer>
        <div class="col-12  d-lg-block ">
            <p class="text-center">&copy;2024 comhub.com || ALL Rights Reserved</p>
            <p class="text-center">Designed By <b>Nimesh Sayuranga</b></p>
        </div>
    </div>
    </div>
</body>

</html>