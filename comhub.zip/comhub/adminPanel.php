<?php

session_start();

require "connection.php";
if (isset($_SESSION["au"])) {

?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Admin Panel | ComHub</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Responsive sidebar template with sliding effect and dropdown menu based on bootstrap 3">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
        <link rel="stylesheet" href="style.css" />
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
        <link rel="icon" href="resourses/logo.svg" />

        <script>
            function init() {
                loadAdminChart();
                loadAdminChart1();
            }
        </script>
    </head>

    <body class="bg" onload="init();">
        <div class="container-fluid">
            <div class="row">

                <div class="page-wrapper chiller-theme toggled">

                    <!-- sidebar -->
                    <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
                        <i class="fas fa-bars"></i>
                    </a>
                    <nav id="sidebar" class="sidebar-wrapper">
                        <div class="sidebar-content">

                            <div class="sidebar-brand">
                                <a href="adminPanel.php">Admin Panel</a>
                                <div id="close-sidebar">
                                    <i class="fas fa-times"></i>
                                </div>
                            </div>

                            <div class="sidebar-header">
                                <div class="user-info">
                                    <span class="user-name">
                                        <h4 class="text-white"><?php echo $_SESSION["au"]["fname"] . " " . $_SESSION["au"]["lname"]; ?></h4>
                                    </span>
                                    <span class="user-role">Administrator</span>
                                    <span class="user-status">
                                        <i class="fa fa-circle"></i>
                                        <span>Online</span>
                                    </span>
                                </div>
                            </div>

                            <div class="sidebar-menu">
                                <ul>

                                    <li>
                                        <a href="adminPanel.php">
                                            <span>Dashboard</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="manageUsers.php">
                                            <span>Manage Users</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="manageSellers.php">
                                            <span>Manage Sellers </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="manageProduct.php">
                                            <span>Manage Product</span>
                                        </a>
                                    </li>

                                    <li class="sidebar-dropdown">
                                        <a href="#">
                                            <span>Report</span>
                                            <span class="badge badge-pill badge-danger">3</span>
                                        </a>
                                        <div class="sidebar-submenu">
                                            <ul>
                                                <li>
                                                    <a href="userReport.php">User Report</a>
                                                </li>
                                                <li>
                                                    <a href="productReport.php">Products Report</a>
                                                </li>
                                                <li>
                                                    <a href="sellerReport.php">Seller & Shop Report</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>

                                </ul>
                            </div>

                        </div>

                        <div class="sidebar-footer text-white fs-6  d-lg-block">
                            <p class="text-center">&copy;2024 comhub.com || ALL Rights Reserved</p>
                            <p class="text-center">Designed By <b>Nimesh Sayuranga</b></p>
                        </div>

                    </nav>
                    <!-- sidebar -->

                    <div class="page-content">
                        <div class="row">

                            <div class=" fw-bold mb-1 mt-3">
                                <h2 class="fw-bold">Dashboard</h2>
                            </div>
                            <div class="col-12">
                                <hr />
                            </div>

                            <div class="col-12">
                                <div class="row g-1">

                                    <div class="col-6 col-lg-4 px-1 shadow">
                                        <div class="row g-1">
                                            <div class="col-12 bg-primary text-white text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Daily Earnings</span>
                                                <br />
                                                <?php

                                                $today = date("Y-m-d");
                                                $thismonth = date("m");
                                                $thisyear = date("Y");

                                                $a = 0;
                                                $b = "0";
                                                $c = "0";
                                                $e = "0";
                                                $f = "0";

                                                $invoice_rs = Database::search("SELECT * FROM `invoice_data` ");
                                                $invoice_num = $invoice_rs->num_rows;

                                                for ($x = 0; $x < $invoice_num; $x++) {
                                                    $invoice_data = $invoice_rs->fetch_assoc();

                                                    $invD_rs = Database::search("SELECT * FROM `invoice_product` WHERE `invoice_data_id`='" . $invoice_data["id"] . "' ");
                                                    $invD_num = $invD_rs->num_rows;

                                                    $d = $invoice_data["date"];
                                                    $splitDate = explode(" ", $d); //separate date from time
                                                    $pdate = $splitDate[0]; //sold date

                                                    for ($i = 0; $i < $invD_num; $i++) {
                                                        $invD_data = $invD_rs->fetch_assoc();
                                                        if ($pdate == $today) {
                                                            $a = $a + ($invD_data["price"] * $invD_data["qty"]);
                                                            $c = $c + $invD_data["qty"];
                                                        }
                                                    }

                                                    $invDa_rs = Database::search("SELECT * FROM `invoice_product` WHERE `invoice_data_id`='" . $invoice_data["id"] . "' ");
                                                    $invDa_num = $invDa_rs->num_rows;

                                                    $splitMonth = explode("-", $pdate); //separate date as year,month & date
                                                    $pyear = $splitMonth[0]; //year
                                                    $pmonth = $splitMonth[1]; //month

                                                    for ($v = 0; $v < $invDa_num; $v++) {
                                                        $invDa_data = $invDa_rs->fetch_assoc();
                                                        if ($pyear == $thisyear) {
                                                            if ($pmonth == $thismonth) {
                                                                $b = $b + ($invDa_data["price"] * $invDa_data["qty"]);
                                                                $e = $e + $invDa_data["qty"];
                                                            }
                                                        }
                                                    }
                                                    $invData_rs = Database::search("SELECT * FROM `invoice_product` WHERE `invoice_data_id`='" . $invoice_data["id"] . "' ");
                                                    $invData_num = $invData_rs->num_rows;
                                                    for ($s = 0; $s < $invData_num; $s++) {
                                                        $invData_data = $invData_rs->fetch_assoc();
                                                        $f = $f + $invData_data["qty"]; //total qty
                                                    }
                                                }
                                                ?>
                                                <span class="fs-5">Rs. <?php echo $a; ?> .00</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-6 col-lg-4 px-1">
                                        <div class="row g-1">
                                            <div class="col-12 bg-white text-black text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Monthly Earning</span>
                                                <br />

                                                <span class="fs-5">Rs. <?php echo $b; ?> .00</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-6 col-lg-4 px-1">
                                        <div class="row g-1">
                                            <div class="col-12 bg-dark text-white text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Today Selling</span>
                                                <br />
                                                <span class="fs-5"><?php echo $c; ?> Items</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-6 col-lg-4 px-1">
                                        <div class="row g-1">
                                            <div class="col-12 bg-secondary text-white text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Monthly Selling</span>
                                                <br />
                                                <span class="fs-5"><?php echo $e; ?> Items</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-6 col-lg-4 px-1">
                                        <div class="row g-1">
                                            <div class="col-12 bg-success text-white text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Total Selling</span>
                                                <br />
                                                <span class="fs-5"><?php echo $f; ?> Items</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-6 col-lg-4 px-1 shadow">
                                        <div class="row g-1">
                                            <div class="col-12 bg-danger text-white text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Total Engagement</span>
                                                <br />
                                                <?php
                                                $user_rs = Database::search("SELECT * FROM `users`");
                                                $user_num = $user_rs->num_rows;
                                                $user_rs1 = Database::search("SELECT * FROM `users`");
                                                $user_num1 = $user_rs1->num_rows;
                                                ?>
                                                <span class="fs-5"><?php echo $user_num + $user_num1; ?> Members</span>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="col-12">
                                <hr />
                            </div>

                            <div class="col-12 bg-dark">
                                <div class="row">
                                    <div class="col-12 col-lg-2 text-center my-3">
                                        <label class="form-label fs-4 fw-bold text-white">Total Active Time</label>
                                    </div>
                                    <div class="col-12 col-lg-10 text-center my-3">
                                        <?php

                                        $start_date = new DateTime("2024-01-01 00:00:00");

                                        $tdate = new DateTime();
                                        $tz = new DateTimeZone("Asia/Colombo");
                                        $tdate->setTimezone($tz);

                                        $end_date = new DateTime($tdate->format("Y-m-d H:i:s"));

                                        $difference = $end_date->diff($start_date);

                                        ?>
                                        <label class="form-label fs-4 fw-bold text-warning">
                                            <?php

                                            echo $difference->format('%Y') . " Years " . $difference->format('%m') . " Months " .
                                                $difference->format('%d') . " Days " . $difference->format('%H') . " Hours " .
                                                $difference->format('%i') . " Minutes " . $difference->format('%s') . " Seconds ";
                                            ?>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 ">
                                <div class="row justify-content-center ">
                                    <div class="card mt-5  col-10 h-auto">
                                        <h4>Last Seven Day Total Earning</h4>
                                        <canvas id="adminChart"></canvas>
                                    </div>
                                    <div class="card mt-5 mb-5 col-10 h-auto">
                                        <h4>12 Month Total Earning</h4>
                                        <canvas id="adminChart1"></canvas>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
            <script src="bootstrap.bundle.js"></script>
            <script src="script.js"></script>
    </body>

    </html>
<?php

} else {
    header("Location: adminSignIn.php");
}

?>