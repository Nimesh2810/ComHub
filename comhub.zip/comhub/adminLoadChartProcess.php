<?php

session_start();

require "connection.php";

$invoice_rs = Database::search("SELECT * FROM `invoice_data` WHERE `date` >= CURDATE() - INTERVAL 7 DAY  ");
$invoice_num = $invoice_rs->num_rows;

$data = [0];
$labels = [0];

for ($i = 0; $i < $invoice_num; $i++) {

    $row = $invoice_rs->fetch_assoc();

    $invD_rs = Database::search("SELECT * FROM `invoice_product` WHERE `invoice_data_id` = '" . $row["id"] . "' ");
    $invD_data = $invD_rs->fetch_assoc();

    $invoice1_rs = Database::search("SELECT * FROM `invoice_data` WHERE `date` = '" . $row["date"] . "' ");
    $invoice_data = $invoice1_rs->fetch_assoc();

    $data[] = $invoice_data["total"];
    $labels[] = $invoice_data["date"];
}

$json = [];
$json["data"] = $data;
$json["labels"] = $labels;

echo json_encode($json);
