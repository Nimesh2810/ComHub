<?php

session_start();

require "connection.php";

$id = $_SESSION["user"]["id"];
$data = [0];
$labels = [0];
$total = [0];
$date = [0];

$invoice_rs = Database::search("SELECT * FROM `invoice_product` WHERE `seller_id` = '" . $id . "'");
$invoice_num = $invoice_rs->num_rows;

if ($invoice_num != 0) {

    for ($i = 0; $i < $invoice_num; $i++) {
        $row = $invoice_rs->fetch_assoc();

        $invD_rs = Database::search("SELECT * FROM `invoice_data` WHERE `date` >= CURDATE() - INTERVAL 7 DAY AND  `id` = '" . $row["invoice_data_id"] . "' ");
        $invD_num = $invD_rs->num_rows;

        $invD_data = $invD_rs->fetch_assoc();

        $invP_rs = Database::search("SELECT * FROM `invoice_product` WHERE `invoice_data_id` = '" . $invD_data["id"] . "' AND `seller_id` = '" . $id . "'");
        $invP_data = $invP_rs->fetch_assoc();

        $total = $invP_data["qty"] * $invP_data["price"];

        $date =  $invD_data["date"];

        $data[] = $total;
        $labels[] = $date;
    }
}

$json = [];
$json["data"] = $data;
$json["labels"] = $labels;


echo json_encode($json);
