<?php

session_start();

require "connection.php";

if (isset($_SESSION["u"])) {

    $email = $_SESSION["u"]["email"];

?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Checkout | ComHub</title>
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
        <link rel="stylesheet" href="style.css" />
        <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
        <link rel="icon" href="resourses/logo.svg" />

    </head>

    <body>
        <div class="container-fluid">
            <div class="row">

                <?php include "header.php"; ?>

                <div class="col-12  pt-2   mt-1" style="background-color: #E3E5E4;">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                        </ol>
                    </nav>
                </div>

                <div class="col-12 mt-3">
                    <div class="row justify-content-center">
                        <?php


                        $user = $_SESSION["u"]["email"];
                        $total = 0;
                        $subtal = 0;
                        $shipping = 0;
                        $total_weight  = 0;

                        $cart_rs = Database::search("SELECT * FROM `cart` WHERE `users_email`='" . $email . "'");
                        $cart_num = $cart_rs->num_rows;
                        ?>

                        <!-- products -->

                        <div class="col-12 col-lg-6">
                            <div class="row">

                                <?php
                                for ($x = 0; $x < $cart_num; $x++) {
                                    $cart_data = $cart_rs->fetch_assoc();

                                    $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $cart_data["product_id"] . "'");
                                    $product_data = $product_rs->fetch_assoc();

                                    $total = $total + ($product_data["price"] * $cart_data["qty"]);


                                    $address_rs = Database::search("SELECT * FROM users_address WHERE `users_email`='" . $email . "'");
                                    $address_data = $address_rs->fetch_assoc();

                                    $shipping = 0;

                                    $w = $product_data["weight"] * $cart_data["qty"];
                                    $fw = ceil($w);
                                    

                                    if ($fw <= 1) {
                                        $shipping = $fw * 350;
                                    } else {
                                        $pwe = $fw - 1;
                                        $fwe = ceil($pwe);
                                        $shipping = ($fwe * 180) + 350;
                                    }

                                    $total_weight = $total_weight + $shipping ;

                                    

                                ?>

                                    <div class="card mb-3 mx-0 col-12">
                                        <div class="row g-0">

                                            <div class="col-12 col-lg-4">
                                                <?php
                                                $img = array();

                                                $images_rs = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $cart_data["product_id"] . "'");
                                                $images_data = $images_rs->fetch_assoc();

                                                ?>
                                                <span class="d-inline-block" tabindex="0" data-bs-toggle="popover" data-bs-trigger="hover focus" data-bs-content="<?php echo $product_data["description"]; ?>" title="Product Description">
                                                    <img src="<?php echo $images_data["img_path"]; ?>" class="img-fluid rounded-start" style="max-width: 200px;">
                                                </span>

                                            </div>

                                            <div class="col-12 col-lg-8">
                                                <div class="card-body">

                                                    <h3 class="card-title mb-5"><?php echo $product_data["title"]; ?></h3>

                                                    <span class="fw-bold text-black-50 fs-5 ">Price :</span>
                                                    <span class="fw-bold text-black fs-5">Rs. <?php echo $product_data["price"]; ?>.00</span>&nbsp;&nbsp;&nbsp;

                                                    <span class="fw-bold text-black-50 fs-5">Quantity :</span>
                                                    <span class="fw-bold text-black fs-5"> <?php echo $cart_data["qty"]; ?></span>
                                                    <br>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <?php
                                }
                                
                                ?>

                            </div>
                        </div>

                        <!-- products -->

                        <!-- summary -->
                        <div class="col-12 col-lg-4">
                            <div class="row">

                                <div class="col-12">
                                    <label class="form-label fs-3 fw-bold">Summary</label>
                                </div>

                                <div class="col-12">
                                    <hr />
                                </div>

                                <div class="col-6 mb-3">
                                    <span class="fs-6 fw-bold">items (<?php echo $cart_num; ?>)</span>
                                </div>

                                <div class="col-6 text-end mb-3">
                                    <span class="fs-6 fw-bold">Rs. <?php echo $total; ?> .00</span>
                                </div>

                                <div class="col-6">
                                    <span class="fs-6 fw-bold">Shipping</span>
                                </div>

                                <div class="col-6 text-end">
                                    <span class="fs-6 fw-bold">Rs. <?php echo $total_weight; ?> .00</span>
                                </div>

                                <div class="col-12 mt-1">
                                    <hr />
                                </div>
                                <?php

                                $userAddress_rs = Database::search("SELECT * FROM `users_address` WHERE `users_email`='" .  $_SESSION["u"]["email"] . "'");
                                $userAddress_data = $userAddress_rs->fetch_assoc();

                                ?>

                                <div class="col-6 ">
                                    <span class="form-label fs-5 fw-bold">Billing Address</span>
                                </div>

                                <div class="col-12">
                                    <hr />
                                </div>

                                <div style="background-color: #E3E5E4;" class="p-3 rounded">
                                    <div class="col-12 ">
                                        <span class="fs-6 fw-bold"><?php  echo  $_SESSION["u"]["fname"]." ".$_SESSION["u"]["lname"];?></span>
                                    </div>

                                    <div class="col-12">
                                        <div class="col-6 ">
                                            <span class="fs-6 fw-bold"><?php echo $userAddress_data["line1"]; ?> ,</span>
                                        </div>
                                        <div class="col-6 ">
                                            <span class="fs-6 fw-bold"><?php echo $userAddress_data["line2"]; ?> .</span>
                                        </div>
                                    </div>

                                    <div class="col-12 ">
                                        <span class="fs-6 fw-bold"><?php echo $userAddress_data["postal_code"]; ?></span>
                                    </div>
                                    <div class="col-12 ">
                                        <span class="fs-6 fw-bold"><?php echo $userAddress_data["city"]; ?></span>
                                    </div>
                                    <div class="col-12 ">
                                        <span class="fs-6 fw-bold"><?php echo $_SESSION["u"]["mobile"]; ?></span>
                                    </div>
                                </div>

                                <div class="col-12 mt-1">
                                    <hr />
                                </div>

                                <div class="col-6 mt-2">
                                    <span class="fs-4 fw-bold">Total</span>
                                </div>

                                <div class="col-6 mt-2 text-end">
                                    <span class="fs-4 fw-bold">Rs. <?php echo $total + $total_weight; ?> .00</span>
                                </div>

                                <div class="col-12 mt-3 mb-3 d-grid">
                                    <button class="btn btn-success" type="submit" id="payhere-payment" onclick="cartPayNow();">Pay Now</button>
                                </div>

                            </div>
                        </div>
                        <!-- summary -->
                    </div>
                </div>

                <?php include "footer.php"; ?>

            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
        <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>
    </body>

    </html>
<?php

} else {
    header("Location: registerForm.php");
}

?>