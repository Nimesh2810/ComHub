<?php

session_start();
require "connection.php";

if (isset($_SESSION["u"])) {


    $order_id = $_GET["orderId"];
    $email =  $_SESSION["u"]["email"];
    $total = 0;
    $shipping = 0;
    $total_weight  = 0;

    $cart_rs = Database::search("SELECT * FROM `cart` WHERE `users_email`='" . $email . "'");
    $cart_num = $cart_rs->num_rows;

    $d = new DateTime();
    $tz = new DateTimeZone("Asia/Colombo");
    $d->setTimezone($tz);
    $date = $d->format("Y-m-d H:i:s");


    Database::iud("INSERT INTO `invoice_data`(`order_id`,`date`,`users_email`) VALUES 
    ('" . $order_id . "','" . $date . "','" . $email . "')");


    for ($x = 0; $x < $cart_num; $x++) {
        $cart_data = $cart_rs->fetch_assoc();

        $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $cart_data["product_id"] . "'");
        $product_data = $product_rs->fetch_assoc();

        

        $total = $total + ($product_data["price"] * $cart_data["qty"]);

        $w = $product_data["weight"] * $cart_data["qty"];
        $fw = ceil($w);


        if ($fw <= 1) {
            $shipping = $fw * 350;
        } else {
            $pwe = $fw - 1;
            $fwe = ceil($pwe);
            $shipping = ($fwe * 180) + 350;
        }

        $total_weight = $total_weight + $shipping;

        $title = $product_data["title"];
        $qty = $cart_data["qty"];
        $price = $product_data["price"];
        $pid = $product_data["id"];
        $seller = $product_data["seller_id"];

        $invD_rs = Database::search("SELECT * FROM `invoice_data` WHERE `order_id`='" . $order_id . "'");
        $invD_Data = $invD_rs->fetch_assoc();
        $id = $invD_Data["id"];

        Database::iud("INSERT INTO `invoice_product`(`title`,`qty`,`price`,`invoice_data_id`,`product_id`,`seller_id`) VALUES 
     ('" . $title . "','" . $qty . "','" . $price . "','" . $id . "','" . $pid . "','" . $seller . "')");

     $current_qty = $product_data["qty"];
     $new_qty = $current_qty - $qty;
     Database::iud("UPDATE `product` SET `qty`='" . $new_qty . "' WHERE `id`='" . $pid . "'");
    }

    $netTotal = $total + $total_weight;

    Database::iud("UPDATE `invoice_data` SET `total`='" . $netTotal . "' WHERE `order_id`='" . $order_id . "'");

    $address_rs = Database::search("SELECT * FROM users_address WHERE `users_email`='" . $email . "'");
    $address_data = $address_rs->fetch_assoc();

    $line1 = $address_data["line1"];
    $line2 = $address_data["line2"];
    $city = $address_data["city"];
    $code = $address_data["postal_code"];


    Database::iud("INSERT INTO `ship_address`(`line1`,`line2`,`city`,`postal_code`,`invoice_data_id`) VALUES 
    ('" . $line1 . "','" . $line2 . "','" . $city . "','" . $code . "','" . $id . "')");

    Database::iud("DELETE FROM `cart` WHERE `users_email`='" . $email . "'");


    echo ("1");
}
