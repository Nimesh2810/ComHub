<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register | ComHub</title>
    <link rel="icon" href="resourses/logo.svg">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
</head>

<body class="bg">
    <div class="container-fluid vh-100 d-flex justify-content-center">
        <div class="row ">
            <div class="col-12 ">
                <div class="row">

                    <div class="col-9 col-lg-9 d-none d-lg-block">
                        <div class="overlay-container vh-100 "></div>
                    </div>

                    <div class="col-10 col-lg-3 vh-100 w-full mx-auto p-2 ">

                        <!--signup box-->
                        <div class="col-12 y-10 d-none  " id="SignUpBox">
                            <div class="row g-2">

                                <div class="col-12  mt-5">
                                    <p class="tittle02 fs-3 text-center">Create New Account</p>
                                </div>

                                <div class="col-12 d-none" id="msgdiv">
                                    <div class="alert alert-danger" role="alert" id="msg">

                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-6">
                                        <label class="form-label">First Name <span class="star">*</span></label>
                                        <input class="form-control" type="text" placeholder="ex: John" id="fname" />
                                    </div>

                                    <div class="col-6">
                                        <label class="form-label">Last Name <span class="star">*</span></label>
                                        <input class="form-control" type="text" placeholder="ex: Doe" id="lname" />

                                    </div>

                                    <div class="col-12">
                                        <label class="form-label">Mobile <span class="star">*</span></label>
                                        <input class="form-control" type="text" placeholder="ex: 077 123 4567" id="mobile" />
                                    </div>

                                    <div class="col-12">
                                        <label class="form-label">Email <span class="star">*</span></label>
                                        <input class="form-control" type="email" placeholder="eex: johndoe@gmail.com" id="email" />
                                    </div>

                                    <div class="col-12">
                                        <label class="form-label">Password <span class="star">*</span></label>
                                        <input class="form-control" type="password" placeholder="ex:********" id="password" />

                                    </div>

                                    <div class="col-12 col-lg-12 d-grid mt-4">
                                        <button class="btn btn-primary" onclick="signUp();">
                                            Sign Up
                                        </button>
                                    </div>

                                    <div class="col-4 col-lg-4 d-grid mt-3">
                                        <a class="link-secondary" onclick="ChangeView();">
                                            &larr; SIGN IN</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--signup box-->

                        <!-- signin box -->
                        <div class="col-12   y-10 " id="SignInBox">
                            <div class="row g-2">

                                <div class="col-12  mt-5">
                                    <p class="tittle02 fs-1 text-center">Sign In</p>
                                </div>

                                <?php
                                $email = "";
                                $password = "";

                                if (isset($_COOKIE["email"])) {
                                    $email = $_COOKIE["email"];
                                }

                                if (isset($_COOKIE["password"])) {
                                    $password = $_COOKIE["password"];
                                }
                                ?>

                                <div class="col-12">
                                    <label class="form-label">Email <span class="star">*</span></label>
                                    <input class="form-control" type="email" id="email2" value="<?php echo $email; ?>" placeholder="ex: johndoe@gmail.com" />
                                </div>

                                <div class="col-12 col-lg-12">
                                    <label class="form-label">Password <span class="star">*</span></label>
                                    <input class="form-control" type="password" id="password2" value="<?php echo $password; ?>" placeholder="ex: ********" />
                                </div>

                                <div class="col-6 col-lg-12 ">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="rememberme">
                                        <label class="form-check-label" for="rememberme">
                                            Remember Me
                                        </label>
                                    </div>
                                </div>

                                <div class="col-12 d-grid">
                                    <button class="btn btn-primary" onclick="signin();"> Sign In</button>
                                </div>
                                <div class=" d-flex col-12 mt-5">
                                    <div class="col-6 ">
                                        <a class="link-primary" onclick="forgotPassword();"> Forgotten Password?</a>
                                    </div>

                                    <div class=" col-6">
                                        <div class=" d-flex justify-content-end">
                                            <a class="link-secondary " onclick="ChangeView();"> SIGN UP &rarr; </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- signin box -->

                    </div>

                </div>
            </div>


            <!-- modal -->
            <div class="modal" tabindex="-1" id="forgotPasswordModal">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Forgot Password?</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row g-3">

                                <div class="col-6">
                                    <label class="form-label">New Password</label>
                                    <div class="input-group mb-3">
                                        <input type="password" class="form-control" id="np" />
                                        <button class="btn btn-outline-secondary" type="button" id="npb" onclick="showPassword();">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="col-6">
                                    <label class="form-label">Retype New Password</label>
                                    <div class="input-group mb-3">
                                        <input type="password" class="form-control" id="rnp" />
                                        <button class="btn btn-outline-secondary" type="button" id="rnpb" onclick="showPassword2();">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <label class="form-label">Verifiction Code</label>
                                    <input type="text" class="form-control" id="vc" />
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" onclick=resetPassword();>Reset Password</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- modal -->

            <!-- footer -->
            <div class="col-12  d-lg-block ">
                <p class="text-center ">&copy;2024 ComHub lk.com || ALL Rights Reserved</p>
            </div>
            <!--footer -->


        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="script.js"></script>
    <script src="bootstrap.js"></script>

</body>

</html>