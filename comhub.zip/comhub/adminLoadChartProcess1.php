<?php

session_start();

require "connection.php";

$invoice_rs = Database::search("SELECT DATE_FORMAT(`date`, '%Y-%m') AS `month`, SUM(`total`) AS `total` FROM `invoice_data` WHERE `date` >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) GROUP BY DATE_FORMAT(`date`, '%Y-%m')
ORDER BY DATE_FORMAT(`date`, '%Y-%m') ASC");
$invoice_num = $invoice_rs->num_rows;

$data = [0];
$labels = [0];

for ($i = 0; $i < $invoice_num; $i++) {

    $row = $invoice_rs->fetch_assoc();

    $data[] = $row["total"];
    $labels[] = $row["month"];
}

$json = [];
$json["data"] = $data;
$json["labels"] = $labels;

echo json_encode($json);
