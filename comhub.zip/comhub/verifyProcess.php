<?php
include "connection.php";

if (isset($_GET["code"])) {

    $code = $_GET["code"];

    $rs = Database::search("SELECT * FROM `seller` WHERE `vcode`='" . $code . "'");
    $num = $rs->num_rows;


    if ($num > 0) {
        $row = $rs->fetch_assoc();
        Database::iud("UPDATE `seller` SET `isverfy`='1', `vcode`= NULL WHERE `id`= '" . $row["id"] . "'");

        echo ("success");
    } else {
        echo ("Invalid Seller Details.");
    }
} else {
    echo ("Invalid Seller Details 01.");
}
