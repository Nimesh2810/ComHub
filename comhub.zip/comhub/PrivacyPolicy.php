<!DOCTYPE html>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy | ComHub</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="icon" href="resourses/logo.svg" />

</head>

<body>
    <div class="container-fluid">
        <div class="row">

            <div class="col-12 ">

                <h1 class="text-center mt-5 text-danger">Privacy Policy</h1>
                <br>
                <h3>ComHub we are committed to safeguarding and preserving the privacy of our visitors and to comply with any applicable
                    data protection and privacy laws. The Privacy Policy applies to all Customers and Users
                    (collectively referred to as “Users”). In addition this Privacy Policy applies to all products and services provided
                    by www.comhub.com (hereinafter referred to as “comhub.com” or the “Site”, “website”).
                    <br>
                    This Privacy Policy explains what happens to any personal data that you provide to us, or that we collect from you whilst you
                    visit our Site. We do update this Policy from time to time so please do review this Policy regularly.
                    <br>
                </h3>
                <h2 class="text-center text-danger">Information We Collect</h2>
                <h3>In running and maintaining our Site we may collect and process the following data about you:</h3>
                <br>
                <h4>i. Information about your use of our Site including details of your visits such as pages viewed and the resources that you access. Such information includes traffic data, location data and other communication data.
                    <br>
                    ii. Information provided voluntarily by you. For example, when you register for information or make a purchase.
                    <br>
                    iii. Information that you provide when you communicate with us by any means.
                </h4>
                <br>

                <h2 class="text-center text-danger ">Use of Cookies</h2>
                <h3>Cookies provide information regarding the computer used by a visitor. We may use cookies where appropriate to gather information about your computer in order to assist us in improving our Website.
                    We may gather information about your general internet use by using the cookie. Where used, these cookies are downloaded to your computer and stored on the computer’s hard drive. Such information will not identify you personally. It is statistical data. This statistical data does not identify any personal details whatsoever
                    You can adjust the settings on your computer to decline any cookies if you wish. This can easily be done by activating the reject cookies setting on your computer.
                    Our advertisers may also use cookies, over which we have no control. Such cookies (if used) would be downloaded once you click on advertisements on our website.
                    Use of Your Information <br>
                    We use the information that we collect from you to provide our services to you. In addition to this we may use the information for one or more of the following purposes:</h3>
                <br>
                <h4>i. To provide information to you that you request from us relating to our products or services.
                    <br>
                    ii. To provide information to you relating to other products that may be of interest to you. Such additional information will only be provided where you have consented to receive such information.
                    <br>
                    iii. To inform you of any changes to our Website, services or goods and products.
                </h4>
                <br>

                <h3>If you have previously purchased goods or services from us, we may provide to you details of similar goods or services, or other goods and services, which you may be interested in.
                    Where your consent has been provided in advance we may allow selected Third Parties to use your data to enable them to provide you with information regarding unrelated goods and services which we believe may interest you. Where such consent has been provided it can be withdrawn by you at any time.
                </h3>
                <h2 class="text-center text-danger ">Storing Your Personal Data</h2>
                <h3>In operating our Website it may become necessary to transfer data that we collect from you to Third Parties. By providing your personal data to us, you agree to this transfer, storing or processing. We do our upmost to ensure that all reasonable steps are taken to make sure that your data is treated stored securely.
                    Unfortunately the sending of information via the internet is not totally secure and on occasion such information can be intercepted. We cannot guarantee the security of data that you choose to send us electronically. Sending such information is entirely at your own risk.
                    Disclosing Your Information
                    <br><br>
                    We will not disclose your personal information to any other party other than in accordance with this Privacy Policy and in the circumstances detailed below:
                </h3>
                <h4>
                    i. In the event that we sell any or all of our business to the buyer.
                    <br>
                    ii. Where we are legally required by law to disclose your personal information.
                    <br>
                    iii. To further fraud protection and reduce the risk of fraud.

                </h4>
                <h2 class="text-center text-danger ">Third Party Links</h2>
                <h3>On occasion we include links to third parties on this Website. Where we provide a link it does not mean that we endorse or approve that site’s policy towards visitor privacy. You should review their privacy policy before sending them any personal data.</h3>
                <h2 class="text-center text-danger ">Contacting Us</h2>
                <br>
                <h3>Please do not hesitate to contact us regarding any matter relating to this Privacy Policy at
                    “Contact Us”
                </h3>
                </p>

            </div>
            
        </div>
    </div>
</body>

</html>