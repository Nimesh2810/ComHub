function showAlert(title, icon) {
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.onmouseenter = Swal.stopTimer;
      toast.onmouseleave = Swal.resumeTimer;
    },
  });
  return Toast.fire({
    icon: icon,
    title: title,
  });
}

function ChangeView() {
  var SignUpBox = document.getElementById("SignUpBox");
  var SignInBox = document.getElementById("SignInBox");

  SignUpBox.classList.toggle("d-none");
  SignInBox.classList.toggle("d-none");
}

function signUp() {
  var fn = document.getElementById("fname");
  var ln = document.getElementById("lname");
  var e = document.getElementById("email");
  var pw = document.getElementById("password");
  var m = document.getElementById("mobile");

  var f = new FormData();
  f.append("fname", fn.value);
  f.append("lname", ln.value);
  f.append("email", e.value);
  f.append("password", pw.value);
  f.append("mobile", m.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        showAlert("User Register Successfully. ", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "signUpProcess.php", true);
  r.send(f);
}

function signin() {
  var email = document.getElementById("email2");
  var password = document.getElementById("password2");
  var rememberme = document.getElementById("rememberme");

  var f = new FormData();
  f.append("e", email.value);
  f.append("p", password.value);
  f.append("r", rememberme.checked);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        showAlert("User Login Successfully", "success").then(() => {
          window.location = "index.php";
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "signinProcess.php", true);
  r.send(f);
}

var bm;
function forgotPassword() {
  var email = document.getElementById("email2");

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      console.log("t");
      var t = r.responseText;
      if (t == "success") {
        var m = document.getElementById("forgotPasswordModal");
        bm = new bootstrap.Modal(m);
        bm.show();
      } else {
        showAlert(t, "error", 3000);
      }
    }
  };

  r.open("GET", "forgotPasswordProcess.php?e=" + email.value, true);
  r.send();
}

function resetPassword() {
  var email = document.getElementById("email2");
  var np = document.getElementById("np");
  var rnp = document.getElementById("rnp");
  var vc = document.getElementById("vc");
  var f = new FormData();
  f.append("e", email.value);
  f.append("np", np.value);
  f.append("rnp", rnp.value);
  f.append("vc", vc.value);
  var r = new XMLHttpRequest();
  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        bm.hide();
        showAlert("Your password has been updated.", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };
  r.open("POST", "resetPasswordProcess.php", true);
  r.send(f);
}
function showPassword() {
  var np = document.getElementById("np");
  var npb = document.getElementById("npb");
  if (np.type == "password") {
    np.type = "text";
    npb.innerHTML = '<i class="bi bi-eye-slash-fill"></i>';
  } else {
    np.type = "password";
    npb.innerHTML = '<i class="bi bi-eye"><i/>';
  }
}
function showPassword2() {
  var rnp = document.getElementById("rnp");
  var rnpb = document.getElementById("rnpb");
  if (rnp.type == "password") {
    rnp.type = "text";
    rnpb.innerHTML = '<i class="bi bi-eye-slash-fill"></i>';
  } else {
    rnp.type = "password";
    rnpb.innerHTML = '<i class="bi bi-eye"><i/>';
  }
}

function signout() {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "Success") {
        showAlert("SignOut Process is Successfully.", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("GET", "signoutProcess.php", true);
  r.send();
}

function changePassword() {
  var pw = document.getElementById("pw");
  var pwv = document.getElementById("pwv");

  if (pw.type == "password") {
    pw.type = "text";
    pwv.innerHTML = '<i class="bi bi-eye"></i>';
  } else {
    pw.type = "password";
    pwv.innerHTML = '<i class="bi bi-eye-slash-fill"><i/>';
  }
}

function updateProfile() {
  var profile_img = document.getElementById("profileImage");
  var first_name = document.getElementById("fname");
  var last_name = document.getElementById("lname");
  var mobile_no = document.getElementById("mobile");
  var email_address = document.getElementById("email");
  var password = document.getElementById("pw");
  var address_line_1 = document.getElementById("line1");
  var address_line_2 = document.getElementById("line2");
  var city = document.getElementById("city");
  var postal_code = document.getElementById("pc");

  var f = new FormData();
  f.append("img", profile_img.files[0]);
  f.append("fn", first_name.value);
  f.append("ln", last_name.value);
  f.append("mn", mobile_no.value);
  f.append("pw", password.value);
  f.append("ea", email_address.value);
  f.append("al1", address_line_1.value);
  f.append("al2", address_line_2.value);
  f.append("c", city.value);
  f.append("pc", postal_code.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;

      if (t == "success") {
        showAlert("Profile Update Successfully", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "userProfileUpdateProcess.php", true);
  r.send(f);
}

function loadBrands() {
  var category = document.getElementById("category").value;

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;

      document.getElementById("brand").innerHTML = t;
    }
  };

  r.open("GET", "loadBrandProcess.php?c=" + category, true);
  r.send();
}

function loadModel() {
  var brand = document.getElementById("brand").value;

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;

      document.getElementById("model").innerHTML = t;
    }
  };

  r.open("GET", "loadModelProcess.php?c=" + brand, true);
  r.send();
}

function changeProductImage() {
  var images = document.getElementById("imageuploader");

  images.onchange = function () {
    var file_count = images.files.length;

    if (file_count <= 3) {
      for (var x = 0; x < file_count; x++) {
        var file = this.files[x];
        var url = window.URL.createObjectURL(file);
        document.getElementById("i" + x).src = url;
      }
    } else {
      alert(
        file_count +
          "files uploaded. You are proceed to upload 03 or less than 03 files."
      );
    }
  };
}

function addProduct() {
  var category = document.getElementById("category");
  var brand = document.getElementById("brand");
  var model = document.getElementById("model");
  var title = document.getElementById("title");
  var desc = document.getElementById("desc");
  var condition = 0;
  if (document.getElementById("b").checked) {
    condition = 1;
  } else if (document.getElementById("u").checked) {
    condition = 2;
  }
  var clr = document.getElementById("clr");
  var qty = document.getElementById("qty");
  var cost = document.getElementById("cost");
  var weight = document.getElementById("weight");
  var image = document.getElementById("imageuploader");

  var f = new FormData();
  f.append("ca", category.value);
  f.append("b", brand.value);
  f.append("m", model.value);
  f.append("t", title.value);
  f.append("desc", desc.value);
  f.append("con", condition);
  f.append("col", clr.value);
  f.append("qty", qty.value);
  f.append("cost", cost.value);
  f.append("weight", weight.value);

  var file_count = image.files.length;
  for (var x = 0; x < file_count; x++) {
    f.append("img" + x, image.files[x]);
  }

  var r = new XMLHttpRequest();
  
  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;

      if (t == "ok") {
        showAlert("Add New Product Successfully", "success").then(() => {
          window.location.reload();
        });
      } else if (t == "1") {
        showAlert("Update Your Shop Profile", "error").then(() => {
          window.location = "shopProfile.php";
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "addProductProcess.php", true);
  r.send(f);
}

function changeStatus(id) {
  var product_id = id;
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;
      if (t == "activated" || t == "deactivated") {
        window.location.reload();
      } else {
        alert(t);
      }
    }
  };

  r.open("GET", "changeStatusProcess.php?p=" + product_id, true);
  r.send();
}

function sort1(x) {
  var search = document.getElementById("s");
  var time = "0";

  if (document.getElementById("n").checked) {
    time = "1";
  } else if (document.getElementById("o").checked) {
    time = "2";
  }

  var qty = "0";

  if (document.getElementById("h").checked) {
    qty = "1";
  } else if (document.getElementById("l").checked) {
    qty = "2";
  }

  var condition = "0";

  if (document.getElementById("b").checked) {
    condition = "1";
  } else if (document.getElementById("u").checked) {
    condition = "2";
  }

  var f = new FormData();
  f.append("s", search.value);
  f.append("t", time);
  f.append("q", qty);
  f.append("c", condition);
  f.append("page", x);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      document.getElementById("sort").innerHTML = t;
    }
  };

  r.open("POST", "sortProcess.php", true);
  r.send(f);
}

function clearsort() {
  window.location.reload();
}

function sendId(id) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;
      if (t == "success") {
        window.location = "updateProduct.php";
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "sendIdProcess.php?id=" + id, true);
  r.send();
}

function updateProduct() {
  var title = document.getElementById("t");
  var qty = document.getElementById("q");
  var description = document.getElementById("d");
  var weight = document.getElementById("weight");
  var image = document.getElementById("imageuploader");

  var f = new FormData();
  f.append("t", title.value);
  f.append("q", qty.value);
  f.append("d", description.value);
  f.append("weight", weight.value);

  var file_count = image.files.length;
  for (var x = 0; x < file_count; x++) {
    f.append("i" + x, image.files[x]);
  }

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;

      if (t == "success") {
        showAlert("Product Update Successfully", "success").then(() => {
          window.location = "myProducts.php";
        });
      } else if (t == "Invalid Image Count") {
        if (confirm("Don't you want to update Product Images?") == true) {
          showAlert("Product Update Successfully", "success").then(() => {
            window.location = "myProducts.php";
          });
        } else {
          showAlert("Pleas Select the Images.", "error");
        }
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "updateProductProcess.php", true);
  r.send(f);
}



function basicSearch(y) {
  var text = document.getElementById("kw").value;
  var select = document.getElementById("c").value;

  var f = new FormData();
  f.append("t", text);
  f.append("s", select);
  f.append("page", y);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;
      document.getElementById("basicSearchResult").innerHTML = t;
    }
  };

  r.open("POST", "basicSearchProcess.php", true);
  r.send(f);
}

function advancedSearch(x) {
  var txt = document.getElementById("t");
  var category = document.getElementById("c1");
  var brand = document.getElementById("b1");
  var model = document.getElementById("m");
  var condition = document.getElementById("c2");
  var color = document.getElementById("c3");
  var from = document.getElementById("pf");
  var to = document.getElementById("pt");
  var sort = document.getElementById("s");

  var f = new FormData();

  f.append("t", txt.value);
  f.append("cat", category.value);
  f.append("b", brand.value);
  f.append("mo", model.value);
  f.append("con", condition.value);
  f.append("col", color.value);
  f.append("pf", from.value);
  f.append("pt", to.value);
  f.append("s", sort.value);
  f.append("page", x);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;
      document.getElementById("view_area").innerHTML = t;
    }
  };

  r.open("POST", "advanceSearchProcess.php", true);
  r.send(f);
}

function home() {
  window.location = "index.php";
}

function loadMainImg(id) {
  var sample_img = document.getElementById("productImg" + id).src;
  var main_img = document.getElementById("mainImg");

  main_img.style.backgroundImage = "url(" + sample_img + ")";
}

function check_value(qty) {
  var input = document.getElementById("qty_input");

  if (input.value <= 0) {
    alert("Quantity must be 1 or more");
    input.value = 1;
  } else if (input.value > qty) {
    alert("Insufficient Quantity.");
    input.value = qty;
  }
}

function qty_inc(qty) {
  var input = document.getElementById("qty_input");

  if (input.value < qty) {
    var newValue = parseInt(input.value) + 1;
    input.value = newValue.toString();
  } else {
    showAlert("Maximum quantity has achieved.", "error");
    input.value = qty;
  }
}

function qty_dec() {
  var input = document.getElementById("qty_input");

  if (input.value > 1) {
    var newValue = parseInt(input.value) - 1;
    input.value = newValue.toString();
  } else {
    showAlert("Minimum quantity has achieved", "error");
    input.value = 1;
  }
}

function addToWatchlist(id) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "added") {
        showAlert("New Product added to the Watch List", "success").then(() => {
          window.location.reload();
        });
      } else if (t == "removed") {
        showAlert("Product Removed to the Watch List", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("GET", "addToWatchlistProcess.php?id=" + id, true);
  r.send();
}

function removeFromWatchlist(id) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        showAlert("Product Remove Successfully.", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("GET", "removeWatchlistProcess.php?id=" + id, true);
  r.send();
}

function addToCart(id) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        showAlert("New Product added to the Cart", "success").then(() => {
          window.location.reload();
        });
      } else if (t == "update") {
        showAlert("Update Finished", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };
  r.open("GET", "addToCartProcess.php?id=" + id, true);
  r.send();
}

function deleteFromCart(id) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        showAlert("Product Remove Successfully.", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("GET", "removeCartProcess.php?id=" + id, true);
  r.send();
}

function cart() {
  window.location = "cart.php";
}



function payNow(pid) {
  var qty = document.getElementById("qty_input").value;

  var r = new XMLHttpRequest();
  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var json = r.responseText;

      var resp = JSON.parse(json);

      if (resp.status == "1") {
        showAlert("Please Log In or Sign up", "error").then(() => {
          window.location = "index.php";
        });
      } else if (resp.status == "2") {
        showAlert("Please Update your Profile First", "error").then(() => {
          window.location = "userProfile.php";
        });
      } else if (resp.status == "success") {
        payhere.onCompleted = function onCompleted(orderId) {
            console.log("Payment completed. OrderID:" + orderId, "success");
            console.log(saveInvoice(orderId,pid,qty));
          };
        
          payhere.onDismissed = function onDismissed() {
            showAlert("Payment dismissed.", "error");
          };
        
          payhere.onError = function onError(error) {
            showAlert(error, "error"); 
          };
        
          payhere.startPayment(resp.payment);
      } else {
        showAlert(resp, "error");
      }
    }
  };

  r.open("GET", "payNowProcess.php?id=" + pid + "&qty=" + qty, true);
  r.send();
}

function cartPayNow() {
  var r = new XMLHttpRequest();
  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var json = r.responseText;

      var resp = JSON.parse(json);

      if (resp.status == "1") {
        showAlert("Please Log In or Sign up", "error").then(() => {
          window.location = "index.php";
        });
      } else if (resp.status == "2") {
        showAlert("Please Update your Profile First", "error").then(() => {
          window.location = "userProfile.php";
        });
      } else if (resp.status == "success") {
        odCheckout(resp.payment, "invoices.php");
      } else {
        showAlert(resp, "error");
      }
    }
  };

  r.open("GET", "paymentNowProcess.php?cart=true", true);
  r.send();
}

function odCheckout(payment, url) {
  payhere.onCompleted = function onCompleted(orderId) {
    console.log("Payment completed. OrderID:" + orderId, "success");
    console.log(invoiceSave(orderId));
  };

  payhere.onDismissed = function onDismissed() {
    showAlert("Payment dismissed.", "error");
  };

  payhere.onError = function onError(error) {
    showAlert(error, "error");
  };

  payhere.startPayment(payment);
}

function invoiceSave(orderId) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == 1) {
        window.location = "invoices.php?id=" + orderId;
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "saveInvoiceProcess.php?orderId=" + orderId, true);
  r.send();
}

var av;
function adminVerification() {
  var email = document.getElementById("e");

  var f = new FormData();
  f.append("e", email.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "success") {
        var adminVerificationModal =
          document.getElementById("verificationModal");
        av = new bootstrap.Modal(adminVerificationModal);
        av.show();
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "adminVerificationProcess.php", true);
  r.send(f);
}

function verify() {
  var verification = document.getElementById("vcode");

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "success") {
        av.hide();
        window.location = "adminPanel.php";
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("GET", "verificationProcess.php?v=" + verification.value, true);
  r.send();
}

function viewMessages(email) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      document.getElementById("chat_box").innerHTML = t;
    }
  };

  r.open("GET", "viewMsgProcess.php?e=" + email, true);
  r.send();
}

function send_msg() {
  var recevr_mail = document.getElementById("rmail");
  var msg_txt = document.getElementById("msg_txt");

  var f = new FormData();
  f.append("rmail", recevr_mail);
  f.append("msg_txt", msg_txt);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "success") {
        document.getElementById("chat_box").reload();
        window.location.reload();
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "sendMsgProcess.php", true);
  r.send(f);
}

function saveInvoice(orderId, pid, qty) {
  var f = new FormData();
  f.append("o", orderId);
  f.append("i", pid);
  f.append("q", qty);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == 1) {
        window.location = "invoices.php?id=" + orderId;
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "saveInvoice.php", true);
  r.send(f);
}



function printInvoice() {
  var restorepage = document.body.innerHTML;
  var page = document.getElementById("page").innerHTML;
  document.body.innerHTML = page;
  window.print();
  document.body.innerHTML = restorepage;
}

function invoice(oid) {
  window.location = "invoices.php?id=" + oid;
}

var mo;
function addFeedback(id) {
  var feedbackModal = document.getElementById("feedbackModal" + id);
  mo = new bootstrap.Modal(feedbackModal);
  mo.show();
}

function saveFeedback(id) {
  var type;

  if (document.getElementById("type1").checked) {
    type = 1;
  } else if (document.getElementById("type2").checked) {
    type = 2;
  } else if (document.getElementById("type3").checked) {
    type = 3;
  }

  var feedback = document.getElementById("feed");

  var f = new FormData();
  f.append("pid", id);
  f.append("t", type);
  f.append("feed", feedback.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == "1") {
        mo.hide();
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "saveFeedbackProcess.php", true);
  r.send(f);
}

function blockUser(email) {
  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4) {
      var txt = request.responseText;
      if (txt == "blocked") {
        document.getElementById("ub" + email).innerHTML = "Unblock";
        document.getElementById("ub" + email).classList = "btn btn-success";
      } else if (txt == "unblocked") {
        document.getElementById("ub" + email).innerHTML = "Block";
        document.getElementById("ub" + email).classList = "btn btn-danger";
      } else {
        showAlert(txt, "error");
      }
    }
  };

  request.open("GET", "userBlockProcess.php?email=" + email, true);
  request.send();
}

function blockSeller(email) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "blocked") {
        document.getElementById("ub" + email).innerHTML = "Unblock";
        document.getElementById("ub" + email).classList = "btn btn-success";
      } else if (t == "unblocked") {
        document.getElementById("ub" + email).innerHTML = "Block";
        document.getElementById("ub" + email).classList = "btn btn-danger";
      } else {
        showAlert(t, "error");
      }
    }
  };
  r.open("GET", "sellerBlockProcess.php?email=" + email, true);
  r.send();
}

function blockProduct(id) {
  var request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4) {
      var txt = request.responseText;
      if (txt == "blocked") {
        document.getElementById("pb" + id).innerHTML = "Unblock";
        document.getElementById("pb" + id).classList = "btn btn-success";
      } else if (txt == "unblocked") {
        document.getElementById("pb" + id).innerHTML = "Block";
        document.getElementById("pb" + id).classList = "btn btn-danger";
      } else {
        showAlert(txt, "error");
      }
    }
  };

  request.open("GET", "productBlockProcess.php?id=" + id, true);
  request.send();
}

var pm;
function viewProductModal(id) {
  var m = document.getElementById("viewProductModal" + id);
  pm = new bootstrap.Modal(m);
  pm.show();
}

var mm;
function viewMsgModal(email) {
  var m = document.getElementById("userMsgModal" + email);
  mm = new bootstrap.Modal(m);
  mm.show();
}

var cm;
var vc;
var e;
var n;

function changeInvoiceStatus(id) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      if (t == 1) {
        document.getElementById("btn" + id).innerHTML = "Packing";
        document.getElementById("btn" + id).classList =
          "btn btn-warning fw-bold mt-1 mb-1";
      } else if (t == 2) {
        document.getElementById("btn" + id).innerHTML = "Dispatch";
        document.getElementById("btn" + id).classList =
          "btn btn-info fw-bold mt-1 mb-1";
      } else if (t == 3) {
        document.getElementById("btn" + id).innerHTML = "Shipping";
        document.getElementById("btn" + id).classList =
          "btn btn-primary fw-bold mt-1 mb-1";
      } else if (t == 4) {
        document.getElementById("btn" + id).innerHTML = "Delivered";
        document.getElementById("btn" + id).classList =
          "btn btn-danger fw-bold mt-1 mb-1 disabled";
      } else {
        alert(t);
      }
    }
  };

  r.open("GET", "changeInvoiceStatusProcess.php?id=" + id, true);
  r.send();
}

// function searchInvoiceId() {
//   var txt = document.getElementById("searchtxt").value;

//   var r = new XMLHttpRequest();

//   r.onreadystatechange = function () {
//     if (r.readyState == 4) {
//       var t = r.responseText;

//       document.getElementById("viewArea").innerHTML = t;
//     }
//   };

//   r.open("GET", "searchInvoiceIdProcess.php?id=" + txt, true);
//   r.send();
// }

function searchInvoice() {
  var txt = document.getElementById("searchtxt").value;

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;

      document.getElementById("viewArea").innerHTML = t;
    }
  };

  r.open("GET", "searchInvoiceProcess.php?id=" + txt, true);
  r.send();
}

function findSellings() {
  var from = document.getElementById("from").value;
  var to = document.getElementById("to").value;

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      document.getElementById("viewArea").innerHTML = t;
    }
  };

  r.open("GET", "findSellingsProcess.php?f=" + from + "&t=" + to, true);
  r.send();
}

function findSelling() {
  var from = document.getElementById("from").value;
  var to = document.getElementById("to").value;

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      document.getElementById("viewArea").innerHTML = t;
    }
  };

  r.open("GET", "findSellingProcess.php?f=" + from + "&t=" + to, true);
  r.send();
}

var cam;
function contactAdmin(email) {
  var m = document.getElementById("contactAdmin");
  cam = new bootstrap.Modal(m);
  cam.show();
}

function sendAdminMsg() {
  var txt = document.getElementById("msgtxt").value;

  var f = new FormData();
  f.append("t", txt);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      alert(t);
    }
  };

  r.open("POST", "sendAdminMessageProcess.php", true);
  r.send(f);
}

function sendAdminMsg(email) {
  var txt = document.getElementById("msgtxt").value;

  var f = new FormData();
  f.append("t", txt);
  f.append("r", email);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4) {
      var t = r.responseText;
      alert(t);
    }
  };

  r.open("POST", "sendAdminMessageProcess.php", true);
  r.send(f);
}

function checkout() {
  window.location = "checkout.php";
}

function sellerSignUp() {
  var fn = document.getElementById("fname");
  var ln = document.getElementById("lname");
  var email = document.getElementById("email");
  var pw = document.getElementById("password");
  var m = document.getElementById("mobile");

  var f = new FormData();
  f.append("fname", fn.value);
  f.append("lname", ln.value);
  f.append("email", email.value);
  f.append("password", pw.value);
  f.append("mobile", m.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        showAlert(
          "Seller Recitation is Successfully Please Check Your Email and Verify Your Email.",
          "success"
        ).then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "sellerSignUpProcess.php", true);
  r.send(f);
}

function sellerSignIn() {
  var email = document.getElementById("email2");
  var password = document.getElementById("password2");

  var f = new FormData();
  f.append("e", email.value);
  f.append("p", password.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        showAlert("Seller Login Successfully", "success").then(() => {
          window.location = "sellerDashboard.php";
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "sellerSigninProcess.php", true);
  r.send(f);
}

function verify1(code) {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "success") {
        showAlert("Seller Verification Successfully", "success").then(() => {
          window.location = "sellerLogin.php";
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("GET", "verifyProcess.php?code=" + code, true);
  r.send();
}

function sellerProfile() {
  var profile_img = document.getElementById("profileImage");
  var first_name = document.getElementById("fname");
  var last_name = document.getElementById("lname");
  var mobile_no = document.getElementById("mobile");
  var email_address = document.getElementById("email");
  var password = document.getElementById("pw");
  var shop_name = document.getElementById("sname");
  var rcode = document.getElementById("rcode");
  var address_line_1 = document.getElementById("line1");
  var address_line_2 = document.getElementById("line2");
  var city = document.getElementById("city");
  var holder_name = document.getElementById("hname");
  var account_number = document.getElementById("anumber");
  var bank = document.getElementById("bank");
  var branch = document.getElementById("branch");

  var f = new FormData();
  f.append("img", profile_img.files[0]);
  f.append("fn", first_name.value);
  f.append("ln", last_name.value);
  f.append("mn", mobile_no.value);
  f.append("pw", password.value);
  f.append("ea", email_address.value);
  f.append("sname", shop_name.value);
  f.append("rcode", rcode.value);
  f.append("al1", address_line_1.value);
  f.append("al2", address_line_2.value);
  f.append("c", city.value);
  f.append("hname", holder_name.value);
  f.append("anumber", account_number.value);
  f.append("bank", bank.value);
  f.append("branch", branch.value);

  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.status == 200 && r.readyState == 4) {
      var t = r.responseText;

      if (t == "success") {
        showAlert("Profile Update Successfully", "success").then(() => {
          window.location.reload();
        });
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("POST", "shopProfileProcess.php", true);
  r.send(f);
}

function sellerSignOut() {
  var r = new XMLHttpRequest();

  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      if (t == "Success") {
        showAlert("Seller SignOut Process is Successfully.", "success").then(
          () => {
            window.location.reload();
          }
        );
      } else {
        showAlert(t, "error");
      }
    }
  };

  r.open("GET", "sellerSignOutProcess.php", true);
  r.send();
}

function loadChart() {
  var chart1 = document.getElementById("chart1");

  var r = new XMLHttpRequest();
  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;

      var json = JSON.parse(t);
      new Chart(chart1, {
        type: "line",

        data: {
          labels: json.labels,
          datasets: [
            {
              label: "Daily Earning",
              data: json.data,
              fill: false,
              borderColor: "rgb(75, 192, 192)",
              tension: 0.1,
            },
          ],
        },
        options: {
          scales: {
            x: {
              beginAtZero: true,
            },
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    }
  };

  r.open("GET", "loadChartProcess.php", true);
  r.send();
}

function loadAdminChart() {
  var adminChart = document.getElementById("adminChart");

  var r = new XMLHttpRequest();
  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      var json = JSON.parse(t);
      new Chart(adminChart, {
        type: "line",

        data: {
          labels: json.labels,
          datasets: [
            {
              label: "Earning",
              data: json.data,
              fill: false,
              borderColor: "rgb(75, 192, 192)",
              tension: 0.1,
            },
          ],
        },
        options: {
          scales: {
            x: {
              beginAtZero: true,
            },
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    }
  };

  r.open("GET", "adminLoadChartProcess.php", true);
  r.send();
}

function loadAdminChart1() {
  var adminChart1 = document.getElementById("adminChart1");

  var r = new XMLHttpRequest();
  r.onreadystatechange = function () {
    if (r.readyState == 4 && r.status == 200) {
      var t = r.responseText;
      var json = JSON.parse(t);
      new Chart(adminChart1, {
        type: "line",

        data: {
          labels: json.labels,
          datasets: [
            {
              label: "Earning",
              data: json.data,
              fill: false,
              borderColor: "rgb(75, 192, 192)",
              tension: 0.1,
            },
          ],
        },
        options: {
          scales: {
            x: {
              beginAtZero: true,
            },
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    }
  };

  r.open("GET", "adminLoadChartProcess1.php", true);
  r.send();
}

function printReport() {
  var original = document.body.innerHTML;
  var printArea = document.getElementById("printArea");

  document.body.innerHTML = printArea.innerHTML;
  window.print();

  document.body.innerHTML = original;
}

// Multi Item Carouse
$(document).ready(function () {
  var itemsMainDiv = ".MultiCarousel";
  var itemsDiv = ".MultiCarousel-inner";
  var itemWidth = "";

  $(".leftLst, .rightLst").click(function () {
    var condition = $(this).hasClass("leftLst");
    if (condition) click(0, this);
    else click(1, this);
  });

  ResCarouselSize();

  $(window).resize(function () {
    ResCarouselSize();
  });

  //this function define the size of the items
  function ResCarouselSize() {
    var incno = 0;
    var dataItems = "data-items";
    var itemClass = ".item";
    var id = 0;
    var btnParentSb = "";
    var itemsSplit = "";
    var sampwidth = $(itemsMainDiv).width();
    var bodyWidth = $("body").width();
    $(itemsDiv).each(function () {
      id = id + 1;
      var itemNumbers = $(this).find(itemClass).length;
      btnParentSb = $(this).parent().attr(dataItems);
      itemsSplit = btnParentSb.split(",");
      $(this)
        .parent()
        .attr("id", "MultiCarousel" + id);

      if (bodyWidth >= 1200) {
        incno = itemsSplit[3];
        itemWidth = sampwidth / incno;
      } else if (bodyWidth >= 992) {
        incno = itemsSplit[2];
        itemWidth = sampwidth / incno;
      } else if (bodyWidth >= 768) {
        incno = itemsSplit[1];
        itemWidth = sampwidth / incno;
      } else {
        incno = itemsSplit[0];
        itemWidth = sampwidth / incno;
      }
      $(this).css({
        transform: "translateX(0px)",
        width: itemWidth * itemNumbers,
      });
      $(this)
        .find(itemClass)
        .each(function () {
          $(this).outerWidth(itemWidth);
        });

      $(".leftLst").addClass("over");
      $(".rightLst").removeClass("over");
    });
  }

  //this function used to move the items
  function ResCarousel(e, el, s) {
    var leftBtn = ".leftLst";
    var rightBtn = ".rightLst";
    var translateXval = "";
    var divStyle = $(el + " " + itemsDiv).css("transform");
    var values = divStyle.match(/-?[\d\.]+/g);
    var xds = Math.abs(values[4]);
    if (e == 0) {
      translateXval = parseInt(xds) - parseInt(itemWidth * s);
      $(el + " " + rightBtn).removeClass("over");

      if (translateXval <= itemWidth / 2) {
        translateXval = 0;
        $(el + " " + leftBtn).addClass("over");
      }
    } else if (e == 1) {
      var itemsCondition = $(el).find(itemsDiv).width() - $(el).width();
      translateXval = parseInt(xds) + parseInt(itemWidth * s);
      $(el + " " + leftBtn).removeClass("over");

      if (translateXval >= itemsCondition - itemWidth / 2) {
        translateXval = itemsCondition;
        $(el + " " + rightBtn).addClass("over");
      }
    }
    $(el + " " + itemsDiv).css(
      "transform",
      "translateX(" + -translateXval + "px)"
    );
  }

  //It is used to get some elements from btn
  function click(ell, ee) {
    var Parent = "#" + $(ee).parent().attr("id");
    var slide = $(Parent).attr("data-slide");
    ResCarousel(ell, Parent, slide);
  }
});

// side bar
jQuery(function ($) {
  $(".sidebar-dropdown > a").click(function () {
    $(".sidebar-submenu").slideUp(200);
    if ($(this).parent().hasClass("active")) {
      $(".sidebar-dropdown").removeClass("active");
      $(this).parent().removeClass("active");
    } else {
      $(".sidebar-dropdown").removeClass("active");
      $(this).next(".sidebar-submenu").slideDown(200);
      $(this).parent().addClass("active");
    }
  });

  $("#close-sidebar").click(function () {
    $(".page-wrapper").removeClass("toggled");
  });
  $("#show-sidebar").click(function () {
    $(".page-wrapper").addClass("toggled");
  });
});
