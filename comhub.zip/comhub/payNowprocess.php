<?php

session_start();
require "connection.php";

if (isset($_SESSION["u"]["email"])) {

    $pid = $_GET["id"];
    $qty = $_GET["qty"];
    $email = $_SESSION["u"]["email"];
    $user = $_SESSION["u"];

    $error = '';
    $shipping = 0;
    $delivery = 0;

    $stockList = [];
    $qtyList = [];

    $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $pid . "'");
    $product_data = $product_rs->fetch_assoc();

    $user_rs = Database::search("SELECT * FROM `users_address` WHERE `users_email`='" . $email . "'");
    $user_num = $user_rs->num_rows;

    if ($user_num == 1) {

        $user_data = $user_rs->fetch_assoc();

        $merchantId = "1224535";
        $merchantSecret = "MTY0OTYwNjIwNzM0MzQyNjc0ODYxMzM4ODczNDU5MTA0NTM5NTk5";
        $items = [];
        $netTotal = 0;
        $currency = "LKR";
        $orderId = uniqid();

        $w = $product_data["weight"] * $qty;
        $fw = ceil($w);

        if ($fw <= 1) {
            $shipping = $fw * 350;
        } else {
            $pwe = $fw - 1;
            $fwe = ceil($pwe);
            $shipping = ($fwe * 180) + 350;
        }
        $delivery = $delivery + $shipping;

        $item = $product_data["title"];
        $qtyList[] = $qty;

        $netTotal = ((int)$product_data["price"] * (int)$qty) + (int)$delivery;

        $hash = strtoupper(
            md5(
                $merchantId .
                    $orderId .
                    number_format($netTotal, 2, '.', '') .
                    $currency .
                    strtoupper(md5($merchantSecret))
            )
        );

        $payment = [];
        $payment["sandbox"] = true;
        $payment["merchant_id"] = $merchantId;
        $payment["return_url"] =  "http://localhost/comhub/index.php";
        $payment["cancel_url"] =  "http://localhost/comhub/index.php";
        $payment["notify_url"] =  "http://sample.com/notify";
        $payment["order_id"] = $orderId;
        $payment["items"] = implode(", ", $items);
        $payment["amount"] = number_format($netTotal, 2, '.', '');
        $payment["currency"] = $currency;
        $payment["hash"] = $hash;
        $payment["first_name"] = $user["fname"];
        $payment["last_name"] = $user["lname"];
        $payment["email"] = $email;
        $payment["phone"] = $user["mobile"];
        $payment["address"] = $user_data["line1"] . " , " . $user_data["line2"];
        $payment["city"] =  $user_data["city"];
        $payment["country"] =    "Sri Lanka";

        $json = [];


        if (empty($error)) {
            $json["status"] = "success";
            $json["payment"] = $payment;
        } else {
            $json["status"] = "error";
            $json["error"] = $error;
        }
    } else {

        $json["status"] = "2";
        $json["error"] = "2";
    }
} else {

    $json["status"] = "1";
    $json["error"] = "1";
}

echo json_encode($json);
