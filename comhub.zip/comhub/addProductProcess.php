<?php

session_start();
require "connection.php";

$email = $_SESSION["user"]["email"];

$category = $_POST["ca"];
$brand = $_POST["b"];
$model = $_POST["m"];
$title = $_POST["t"];
$desc = $_POST["desc"];
$condition = $_POST["con"];
$clr = $_POST["col"];
$qty = $_POST["qty"];
$cost = $_POST["cost"];
$weight = $_POST["weight"];

if (empty($category)) {
    echo ("Please enter Product Category.");
} else if (empty($brand)) {
    echo ("Please enter Product Brand.");
} else if (empty($model)) {
    echo ("Please enter Product Model.");
} else if (empty($title)) {
    echo ("Please enter Product Title.");
} else if (empty($desc)) {
    echo ("Please enter Product Description.");
} else if (empty($condition)) {
    echo ("Please Select Product Condition.");
} else if (empty($clr)) {
    echo ("Please enter Product Color.");
} else if (empty($qty)) {
    echo ("Please enter Product Quantity.");
} else if (empty($cost)) {
    echo ("Please Select Item Price.");
} else if (empty($weight)) {
    echo ("Please Select Item Weight.");
} else {

    $seller_rs = Database::search("SELECT * FROM `seller` WHERE `email` = '" . $email . "'");
    $seller_num = $seller_rs->num_rows;
    $seller_data = $seller_rs->fetch_assoc();

    $sellerData_rs = Database::search("SELECT * FROM `seller_details` WHERE `seller_id` = '" . $seller_data["id"] . "'");
    $sellerData_num = $sellerData_rs->num_rows;

    if ($sellerData_num == 1) {


        Database::iud("INSERT INTO `model`(`model_name`) VALUES ('" . $model . "')");

        $model_rs = Database::search("SELECT * FROM `model` WHERE `model_name`='" . $model . "'");
        $model_id;
        $model_data = $model_rs->fetch_assoc();
        $model_id = $model_data["model_id"];

        $mhb_rs = Database::search("SELECT * FROM `model_has_brand` WHERE `model_model_id`='" . $model_id . "' AND `brand_brand_id`='" . $brand . "'");

        $mhb_id;

        if ($mhb_rs->num_rows > 0) {

            $mhb_data = $mhb_rs->fetch_assoc();
            $mhb_id = $mhb_data["id"];
        } else {
            Database::iud("INSERT INTO `model_has_brand`(`model_model_id`,`brand_brand_id`) VALUES ('" . $model_id . "','" . $brand . "')");
            $mhb_id = Database::$connection->insert_id;
        }

        $d = new DateTime();
        $tz = new DateTimeZone("Asia/Colombo");
        $d->setTimezone($tz);
        $date = $d->format("Y-m-d H:i:s");

        $status = 1;
        Database::iud("INSERT INTO `product`(`price`,`qty`,`description`,`title`,`datetime_added`,
            `category_cat_id`,`model_has_brand_id`,`color_clr_id`,
            `status_status_id`,`condition_condition_id`,`weight`,`seller_id`) VALUES ('" . $cost . "','" . $qty . "',
            '" . $desc . "','" . $title . "','" . $date . "','" . $category . "','" . $mhb_id . "',
            '" . $clr . "','" . $status . "','" . $condition . "','" . $weight . "','" . $seller_data["id"] . "')");

        echo ("ok");

        $product_id = Database::$connection->insert_id;

        $length = sizeof($_FILES);

        if ($length <= 3 && $length > 0) {

            $allowed_img_extentions = array("image/jpg", "image/jpeg", "image/png", "image/svg+xml");

            for ($x = 0; $x < $length; $x++) {
                if (isset($_FILES["img" . $x])) {

                    $img_file = $_FILES["img" . $x];
                    $file_extention = $img_file["type"];

                    if (in_array($file_extention, $allowed_img_extentions)) {

                        $new_img_extention;

                        if ($file_extention == "image/jpg") {
                            $new_img_extention = ".jpg";
                        } else if ($file_extention == "image/jpeg") {
                            $new_img_extention = ".jpeg";
                        } else if ($file_extention == "image/png") {
                            $new_img_extention = ".png";
                        } else if ($file_extention == "image/svg+xml") {
                            $new_img_extention = ".svg";
                        }

                        $file_name = "resourses/product/" . $title . "_" . $x . "_" . uniqid() . $new_img_extention;
                        move_uploaded_file($img_file["tmp_name"], $file_name);
                        Database::iud("INSERT INTO `product_img`(`img_path`,`product_id`) VALUES ('" . $file_name . "','" . $product_id . "')");
                    } else {
                        echo ("Not an allowed image type.");
                    }
                }
            }
        } else {
            echo ("Invalid Image Count");
        }
    } else {
        echo ("1");
    }
}
