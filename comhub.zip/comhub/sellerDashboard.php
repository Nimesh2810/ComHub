<?php

session_start();

require "connection.php";

if (isset($_SESSION["user"])) {
    $id = $_SESSION["user"]["id"];
    $total = 0;

?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Seller Dashboard| ComHub</title>
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" />
        <link rel="stylesheet" href="style.css" />
        <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
        <link rel="icon" href="resourses/logo.svg" />
        <script>
            function init() {
                loadChart();
            }
        </script>
    </head>

    <body onload="init();">

        <div class="container-fluid">
            <div class="row ">

                <?php include "sellerHeader.php"; ?>

                <div class="col-10  offset-1 mt-4 bg-secondary  bg-opacity-10">
                    <div class="row  justify-content-center">

                        <div class="col-12 ">
                            <div class="row justify-content-center">

                                <div class="col-5  ">
                                    <div class="col-10 py-1 shadow">
                                        <div class="row g-1">
                                            <div class="col-12 bg-primary text-white text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Daily Earnings</span>
                                                <br />
                                                <?php

                                                $today = date("Y-m-d");
                                                $thismonth = date("m");
                                                $thisyear = date("Y");

                                                $a = "0";
                                                $b = "0";
                                                $c = "0";
                                                $e = "0";
                                                $f = "0";

                                                $invoice_rs = Database::search("SELECT * FROM `invoice_data` ");
                                                $invoice_num = $invoice_rs->num_rows;

                                                for ($x = 0; $x < $invoice_num; $x++) {
                                                    $invoice_data = $invoice_rs->fetch_assoc();

                                                    $invD_rs = Database::search("SELECT * FROM `invoice_product` WHERE `seller_id`='" . $id . "'");
                                                    $invD_num = $invD_rs->num_rows;
                                                    $invD_data = $invD_rs->fetch_assoc();

                                                    $f = $f + $invD_data["qty"]; //total qty

                                                    $d = $invoice_data["date"];
                                                    $splitDate = explode(" ", $d); //separate date from time
                                                    $pdate = $splitDate[0]; //sold date

                                                    if ($pdate == $today) {
                                                        $a = $a + $invD_data["price"];
                                                        $c = $c + $invD_data["qty"];
                                                    }

                                                    $splitMonth = explode("-", $pdate); //separate date as year,month & date
                                                    $pyear = $splitMonth[0]; //year
                                                    $pmonth = $splitMonth[1]; //month

                                                    if ($pyear == $thisyear) {
                                                        if ($pmonth == $thismonth) {
                                                            $b = $b + $invD_data["price"];
                                                            $e = $e + $invD_data["qty"];
                                                        }
                                                    }
                                                }

                                                ?>
                                                <span class="fs-5">Rs. <?php echo $a; ?> .00</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-10 py-1 shadow">
                                        <div class="row g-1">
                                            <div class="col-12 bg-dark text-white text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Today Selling</span>
                                                <br />
                                                <span class="fs-5"><?php echo $c; ?> Items</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-5 ">

                                    <div class="col-10 py-1 shadow">
                                        <div class="row g-1">
                                            <div class="col-12 bg-white text-black text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Monthly Earnings</span>
                                                <br />
                                                <span class="fs-5">Rs. <?php echo $b; ?> .00</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-10 py-1 shadow">
                                        <div class="row g-1">
                                            <div class="col-12 bg-secondary text-white text-center rounded" style="height: 100px;">
                                                <br />
                                                <span class="fs-4 fw-bold">Monthly Sellings</span>
                                                <br />
                                                <span class="fs-5"><?php echo $e; ?> Items</span>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>


                        <div class="col-6 col-lg-4 py-1">
                            <div class="row g-1">
                                <div class="col-12 bg-success text-white text-center rounded" style="height: 100px;">
                                    <br />
                                    <span class="fs-4 fw-bold">Total Sellings</span>
                                    <br />
                                    <span class="fs-5"><?php echo $f; ?> Items</span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-12 ">
                    <div class="row justify-content-center gap-3">
                        <div class="col-10">
                            <div class="card mt-5  h-auto ">
                                <h4>7 Day Earning</h4>
                                <canvas id="chart1"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <?php include "footer.php"; ?>

            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
    </body>

    </html>
<?php

} else {
    header("Location: sellerLogin.php");
}



?>