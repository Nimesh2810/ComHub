<?php

require "connection.php";

if (isset($_GET["email"])) {


    $seller_email = $_GET["email"];

    $seller_rs = Database::search("SELECT * FROM `seller` WHERE `email`='" . $seller_email . "'");
    $seller_num = $seller_rs->num_rows;
    if ($seller_num == 1) {

        $seller_data = $seller_rs->fetch_assoc();

        if ($seller_data["status"] == 1) {
            Database::iud("UPDATE `seller` SET `status`= '0' WHERE `email`='" . $seller_email . "'");
            echo ("blocked");
        } else if ($seller_data["status"] == 0) {
            Database::iud("UPDATE `seller` SET `status`= '1' WHERE `email`='" . $seller_email . "'");
            echo ("unblocked");
        }
    } else {
        echo ("Cannot find the Seller. Please try again later.");
    }
} else {
    echo ("Something went wrong.");
}
