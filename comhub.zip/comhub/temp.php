<?php

session_start();

require "connection.php";

if (isset($_SESSION["u"])) {

    $email = $_SESSION["u"]["email"];
?>
    <!DOCTYPE html>

    <html>

    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ComHub | User Profile</title>
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
        <link rel="stylesheet" href="style.css" />
        <link rel="icon" href="resourses/logo.svg" />

    </head>

    <body>

        <div class="container-fluid">
            <div class="row">

                <?php

                require "header.php";





                $details_rs = Database::search("SELECT * FROM `users`  WHERE `email`='" . $email . "'");

                $image_rs = Database::search("SELECT * FROM `profile_img` WHERE `users_email`='" . $email . "'");

                $address_rs = Database::search("SELECT * FROM `users_address` WHERE `users_email`='" . $email . "'");

                $details_data = $details_rs->fetch_assoc();
                $image_data = $image_rs->fetch_assoc();
                $address_data = $address_rs->fetch_assoc();

                ?>

                <div class="col-12 bg-primary">
                    <div class="row">

                        <div class="col-12 bg-body mt-4 mb-4">
                            <div class="row g-2">

                                <div class="col-md-3 border-end">
                                    <div class="d-flex flex-column align-items-center text-center p-3 py-5">

                                        <?php

                                        if (empty($image_data["path"])) {
                                        ?>
                                            <img src="resourses/user.svg" width="200px" height="200px" class="rounded-circle"  />
                                        <?php
                                        } else {
                                        ?>
                                            <button class="rounded-circle" for="profileImage"><img src="<?php echo $image_data["path"]; ?>" width="200px" height="200px" class="rounded-circle" /></button>
                                        <?php
                                        }

                                        ?>

                                        <br />

                                        <span class="fw-bold"><?php echo $details_data["fname"] . " " . $details_data["lname"]; ?></span>
                                        <span class="fw-bold text-black-50"><?php echo $email; ?></span>

                                        <input type="file" class="d-none " id="profileImage" />
                                        <label for="profileImage" class="btn btn-primary mt-3">Update Profile Image</label>

                                    </div>
                                </div>

                                <div class="col-md-5 border-end">
                                    <div class="p-3 py-5">

                                        <div class="d-flex justify-content-center align-items-center mb-3">
                                            <h4 class="fw-bold">Profile Settings</h4>
                                        </div>

                                        <div class="row">

                                            <div class="mb-3 mt-3 col-12 ">
                                                <hr class="border border-1 border-secondary mb-1" />
                                                <h5 class="fw-bold">User Details</h5>
                                                <hr class="border border-1 border-secondary mt-1" />
                                            </div>

                                            <div class="col-6">
                                                <label class="form-label">First Name</label>
                                                <input type="text" id="fname" class="form-control" value="<?php echo $details_data["fname"]; ?>" />
                                            </div>

                                            <div class="col-6">
                                                <label class="form-label">Last Name</label>
                                                <input type="text" id="lname" class="form-control" value="<?php echo $details_data["lname"]; ?>" />
                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Mobile Number</label>
                                                <input type="text" id="mobile" class="form-control" value="<?php echo $details_data["mobile"]; ?>" />
                                            </div>

                                            <div class="col-6">
                                                <label class="form-label">Email</label>
                                                <input type="text" id="email" class="form-control" readonly value="<?php echo $email; ?>" />
                                            </div>

                                            <div class="col-6">
                                                <label class="form-label">Password</label>
                                                <div class="input-group">
                                                    <input type="password" value="<?php echo $details_data["password"]; ?>" class="form-control" aria-describedby="basic-addon2" id="pw" />
                                                    <button class="input-group-text" id="basic-addon2  " onclick=" changePassword();" id="pwv">
                                                        <i class="bi bi-eye"></i>
                                                    </button>
                                                </div>
                                            </div>

                                            <div class="mb-3 mt-3 col-12 ">
                                                <hr class="border border-1 border-secondary mb-1" />
                                                <h5 class="fw-bold">Billing Address</h5>
                                                <hr class="border border-1 border-secondary mt-1" />
                                            </div>

                                            <?php
                                            if (!empty($address_data["line1"])) {
                                            ?>
                                                <div class="col-6">
                                                    <label class="form-label">Address Line 01</label>
                                                    <input type="text" id="line1" class="form-control" placeholder="Enter Address Line 01" value="<?php echo $address_data["line1"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-6">
                                                    <label class="form-label">Address Line 01</label>
                                                    <input type="text" id="line1" class="form-control" placeholder="Enter Address Line 01" />
                                                </div>
                                            <?php } ?>

                                            <?php
                                            if (!empty($address_data["line2"])) {
                                            ?>
                                                <div class="col-6">
                                                    <label class="form-label">Address Line 01</label>
                                                    <input type="text" id="line2" class="form-control" placeholder="Enter Address Line 01" value="<?php echo $address_data["line2"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-6">
                                                    <label class="form-label">Address Line 01</label>
                                                    <input type="text" id="line2" class="form-control" placeholder="Enter Address Line 02" />
                                                </div>
                                            <?php } ?>

                                            <?php
                                            if (!empty($address_data["city"])) {
                                            ?>
                                                <div class="col-6">
                                                    <label class="form-label">City</label>
                                                    <input type="text" class="form-control" id="city" placeholder="Enter Your City" value="<?php echo $address_data["city"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-6">
                                                    <label class="form-label">City</label>
                                                    <input type="text" class="form-control" id="city" placeholder="Enter Your City" />
                                                </div>
                                            <?php } ?>

                                            <?php
                                            if (!empty($address_data["postal_code"])) {
                                            ?>
                                                <div class="col-6">
                                                    <label class="form-label">Postal Code</label>
                                                    <input type="text" id="pc" class="form-control" placeholder="Enter Your Postal Code" value="<?php echo $address_data["postal_code"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-6">
                                                    <label class="form-label">Postal Code</label>
                                                    <input type="text" id="pc" class="form-control" placeholder="Enter Your Postal Code" />
                                                </div>
                                            <?php } ?>

                                            <div class="col-12 d-grid mt-2">
                                                <button class="btn btn-primary" onclick="updateProfile();">Update My Profile</button>
                                            </div>

                                        </div>

                                    </div>
                                </div>

                                <div class="col-md-4 ">
                                    <div class="p-3 py-5">

                                        <div class="d-flex justify-content-center align-items-center mb-3">
                                            <h4 class="fw-bold text-danger fs-1">Important</h4>
                                        </div>

                                        <h5 class="fs-4"> For this we expect that the data yoy receive is true information. And please Enter
                                            the data you enter correctly and your true status, because we will carry out future
                                            work based on the data you enter, and we need your true information for future transactions with us.
                                        </h5>

                                        <h5 class="fs-4"> At the same time, we and our working group are committed to protecting the information you provide.</h5>

                                        <h5 class="fs-4"> Thank to the founder of the ComHub business. </h5>

                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>


                <?php
                require "footer.php";
                ?>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>

    </body>

    </html>
<?php

} else {
    header("Location: registerForm.php");
}

?>