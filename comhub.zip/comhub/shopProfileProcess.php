<?php

session_start();

require "connection.php";

if (isset($_SESSION["user"])) {

    $seller_email = $_SESSION["user"]["email"];

    $fname = $_POST["fn"];
    $lname = $_POST["ln"];
    $mobile = $_POST["mn"];
    $pw = $_POST["pw"];
    $email = $_POST["ea"];
    $shop_name = $_POST["sname"];
    $rcode = $_POST["rcode"];
    $line1 = $_POST["al1"];
    $line2 = $_POST["al2"];
    $city = $_POST["c"];
    $holder_name = $_POST["hname"];
    $account_number = $_POST["anumber"];
    $bank = $_POST["bank"];
    $branch = $_POST["branch"];

    if (empty($shop_name)) {
        echo ("Please enter your Shop Name.");
    } else if (strlen($shop_name) > 45) {
        echo ("Shop Name must have less than 45 characters.");
    } else if (empty($rcode)) {
        echo ("Please enter your Business Register Number.");
    } else if (strlen($rcode) > 6) {
        echo ("Business Register Number must have less than 6 characters.");
    } else if (empty($line1)) {
        echo ("Please enter your Address.");
    } else if (strlen($line1) > 45) {
        echo ("Address Line 1 must have less than 45 characters.");
    } else if (empty($line2)) {
        echo ("Please enter your Address.");
    } else if (strlen($line2) > 45) {
        echo ("Address Line 2 must have less than 45 characters.");
    } else if (empty($city)) {
        echo ("Please enter your City.");
    } else if (empty($holder_name)) {
        echo ("Please enter Account Holder Name.");
    } else if (strlen($holder_name) > 45) {
        echo ("Account Holder Name must have less than 45 characters.");
    } else if (empty($account_number)) {
        echo ("Please enter your Bank Account Number.");
    } else if (!preg_match("/^[0-9]{9,18}$/", $account_number)) {
        echo ("Please enter Valid Bank Account Number.");
    } else if (empty($bank)) {
        echo ("Please enter your Bank Name.");
    } else if (empty($branch)) {
        echo ("Please enter your Place of Bank.");
    } else {

        $seller_rs = Database::search("SELECT * FROM `seller` WHERE `email` = '" . $seller_email . "'");
        $seller_num = $seller_rs->num_rows;
        $seller_data = $seller_rs->fetch_assoc();

        $address_rs = Database::search("SELECT * FROM `seller_details` WHERE `seller_id`='" . $seller_data["id"] . "' ");
        $address_num = $address_rs->num_rows;

        if ($address_num == 1) {
            Database::iud("UPDATE `seller_details` SET `address1`='" . $line1 . "', `address2`='" . $line2 . "', `city`='" . $city . "', `register_no`='" . $rcode . "', `shop_name`='" . $shop_name . "',
             `account_holder`='" . $holder_name . "', `account_number`='" . $account_number . "', `bank`='" . $bank . "', `branch`='" . $branch . "' WHERE `seller_id`='" . $seller_data["id"] . "'");
        } else {
            Database::iud("INSERT INTO `seller_details`(`address1`, `address2`, `city`, `register_no`, `seller_id`, `shop_name`, `account_holder`, `account_number`, `bank`, `branch`) 
                        VALUES ('" . $line1 . "', '" . $line2 . "', '" . $city . "', '" . $rcode . "', '" . $seller_data["id"] . "', '" . $shop_name . "', '" . $holder_name . "', '" . $account_number . "',
                        '" . $bank . "', '" . $branch . "' )");
        }

        $allowed_image_extentions = array("image/jpg", "image/jpeg", "image/png", "image/svg+xml");

        if (isset($_FILES["img"])) {

            $img = $_FILES["img"];
            $file_type = $img["type"];

            if (in_array($file_type, $allowed_image_extentions)) {

                $new_file_type;

                if ($file_type == "image/jpg") {
                    $new_file_type = ".jpg";
                } else if ($file_type == "image/jpeg") {
                    $new_file_type = ".jpeg";
                } else if ($file_type == "image/png") {
                    $new_file_type = ".png";
                } else if ($file_type == "image/svg+xml") {
                    $new_file_type = ".svg";
                }

                $file_name = "resourses//profile_images//" . $shop_name . "_" . $mobile . "_" . uniqid() . $new_file_type;
                move_uploaded_file($img["tmp_name"], $file_name);

                $image_rs = Database::search("SELECT * FROM `shop_img` WHERE `seller_id` = '" . $seller_data["id"] . "'");

                $image_num = $image_rs->num_rows;

                if ($image_num == 1) {

                    Database::iud("UPDATE `shop_img` SET `path`='" . $file_name . "' WHERE 
                            `seller_id` = '" . $seller_data["id"] . "'");
                } else {

                    Database::iud("INSERT INTO `shop_img`(`path`,`seller_id`) VALUES 
                            ('" . $file_name . "','" . $seller_data["id"] . "')");
                }
            } else {

                echo ("File type does not allowed to upload");
            }
        } else {
            // echo ("Image Not Updated");
        }

        if ($seller_num == 1) {

            Database::iud("UPDATE `seller` SET `fname`='" . $fname . "',`lname`='" . $lname . "',`email`='" . $email . "',`password`='" . $pw . "',`mobile`='" . $mobile . "' WHERE `email` = '" . $seller_email . "'");

            echo ("success");
        } else {

            echo ("You are not a valid user");
        }
    }
}
