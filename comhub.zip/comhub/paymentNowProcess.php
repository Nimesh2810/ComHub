<?php

session_start();
require "connection.php";

if (isset($_SESSION["u"]["email"])) {

    $user = $_SESSION["u"];
    $email = $_SESSION["u"]["email"];

    $error = '';
    $shipping = 0;

    $stockList = [];
    $qtyList = [];

    $user_rs = Database::search("SELECT * FROM `users_address` WHERE `users_email`='" . $email . "'");
    $user_num = $user_rs->num_rows;

    if ($user_num == 1) {

        $address = $user_rs->fetch_assoc();

        if (isset($_GET["cart"]) && $_GET["cart"] == "true") {

            $rs = Database::search("SELECT * FROM `cart` WHERE `users_email`='" . $email . "'");
            $num = $rs->num_rows;

            for ($i = 0; $i < $num; $i++) {
                $row = $rs->fetch_assoc();

                $stockList[] = $row["product_id"];
                $qtyList[] = $row["qty"];
            }
        }

        $merchantId = "1224535";
        $merchantSecret = "MTY0OTYwNjIwNzM0MzQyNjc0ODYxMzM4ODczNDU5MTA0NTM5NTk5";
        $items = [];
        $netTotal = 0;
        $currency = "LKR";
        $orderId = uniqid();

        for ($x = 0; $x < sizeof($stockList); $x++) {

            $stockRs = Database::search("SELECT * FROM `product` WHERE `id`='" . $stockList[$x] . "'");
            $stock =  $stockRs->fetch_assoc();

            $stockQty = $stock["qty"];

            if ($stockQty >= $qtyList[$x]) {
                $item[] = $stock["title"];
                $netTotal += $stock["price"] * $qtyList[$x];
            } else {
                $error = "Insufficient Quantity";
            }

            $w = $stock["weight"] *$row["qty"];
            $fw = ceil($w);
    
    
            if ($fw <= 1) {
                $shipping = $fw * 350;
            } else {
                $pwe = $fw - 1;
                $fwe = ceil($pwe);
                $shipping = ($fwe * 180) + 350;
            }
            $netTotal += (int)$shipping;
        }

       
        

        $hash = strtoupper(
            md5(
                $merchantId .
                    $orderId .
                    number_format($netTotal, 2, '.', '') .
                    $currency .
                    strtoupper(md5($merchantSecret))
            )
        );

        $payment = [];
        $payment["sandbox"] = true;
        $payment["merchant_id"] = $merchantId;
        $payment["return_url"] = "http://localhost/comhub/index.php";
        $payment["cancel_url"] = "http://localhost/comhub/index.php";
        $payment["notify_url"] =  "http://sample.com/notify";
        $payment["order_id"] = $orderId;
        $payment["items"] = implode(", ", $items);
        $payment["amount"] = number_format($netTotal, 2, '.', '');
        $payment["currency"] = $currency;
        $payment["hash"] = $hash;
        $payment["first_name"] = $user["fname"];
        $payment["last_name"] = $user["lname"];
        $payment["email"] = $email;
        $payment["phone"] = $user["mobile"];
        $payment["address"] = $address["line1"] . " , " . $address["line2"];
        $payment["city"] =  $address["city"];
        $payment["country"] =    "Sri Lanka";

        $json = [];

        if (empty($error)) {
            $json["status"] = "success";
            $json["payment"] = $payment;
        } else {
            $json["status"] = "error";
            $json["error"] = $error;
        }
    } else {
        $json["status"] = "2";
        $json["error"] = "2";
    }
} else {

    $json["status"] = "1";
    $json["error"] = "1";
}

echo json_encode($json);
