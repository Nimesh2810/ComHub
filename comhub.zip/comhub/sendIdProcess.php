<?php

session_start();
require "connection.php";

$email = $_SESSION["user"]["email"];
$pid = $_GET["id"];

$seller_rs = Database::search("SELECT * FROM `seller` WHERE `email` = '" . $email . "'");
$seller_data = $seller_rs->fetch_assoc();

$product_rs = Database::search("SELECT * FROM `product` WHERE `id`='".$pid."' AND
                                 `seller_id`= '". $seller_data["id"]."' ");

$product_num =$product_rs->num_rows;

if($product_num == 1){

    $product_data = $product_rs->fetch_assoc();
    $_SESSION["p"] = $product_data;
    echo ("success");

}else{
    echo ("Something went wrong");
}

?>