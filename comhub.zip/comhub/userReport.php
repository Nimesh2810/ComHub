<?php
session_start();
require "connection.php";
if (isset($_SESSION["au"])) {
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>User Reports | Admins | ComHub</title>

        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
        <link rel="stylesheet" href="style.css" />
        <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
        <link rel="icon" href="resourses/logo.svg" />

    </head>

    <body class="bg">

        <div class="container-fluid">
            <div class="row">

                <div class="col-6 mt-5 d-flex justify-content-start ">
                    <button class="btn btn-dark" onclick="history.back();"><i class="bi bi-arrow-left"></i>BACK</button>
                </div>
                <div class="col-6 mt-5 d-flex justify-content-end ">
                    <button class="btn btn-danger me-2" onclick="printReport();"><i class="bi bi-printer-fill"></i> Print</button>
                </div>

                <div class="container">
                    <div class="row" id="printArea">
                        <div class="col-12 text-center mt-5">
                            <h1>User Report</h1>
                        </div>
                        <div class="col-12 mt-5 table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Profile</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $rs = Database::search("SELECT * FROM `users` ");
                                    $num = $rs->num_rows;

                                    for ($x = 0; $x < $num; $x++) {
                                        $row = $rs->fetch_assoc();

                                        $rs1 = Database::search("SELECT * FROM `profile_img` WHERE `users_email`='" . $row["email"] . "' ");
                                        $row1 = $rs1->fetch_assoc();
                                    ?>
                                        <tr>
                                            <td><?php echo $x + 1; ?></td>
                                            <td>

                                                <?php

                                                if (empty($row1["path"])) {
                                                ?>
                                                    <img src="resourses/user.svg" height="50px" width="50px" />
                                                <?php
                                                } else {
                                                ?>
                                                    <img src="<?php echo $row1["path"]; ?>" height="50px" width="50px" />
                                                <?php
                                                }

                                                ?>
                                            </td>
                                            <td><?php echo ($row["fname"] . " " . $row["lname"]); ?></td>
                                            <td><?php echo ($row["email"]); ?></td>
                                            <td><?php echo ($row["mobile"]); ?></td>
                                            <td>
                                                <?php
                                                if ($row["status"] == '1') {
                                                    echo ("Active");
                                                } else {
                                                    echo ("Inactive");
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="fixed-bottom col-12">
                    <p class="text-center">&copy;2024 comhub.com || ALL Rights Reserved</p>
                    <p class="text-center">Designed By <b>Nimesh Sayuranga</b></p>
                </div>

            </div>
        </div>



        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
    </body>

    </html>

<?php

} else {
    header("Location: adminSignIn.php");
}

?>