<?php
session_start();
require "connection.php";

if (isset($_SESSION["u"])) {
    $email = $_SESSION["u"]["email"];
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Purchasing History | ComHub</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
        <link rel="stylesheet" href="style.css" />
        <link rel="icon" href="resourses/logo.svg" />
    </head>

    <body>

        <div class="container-fluid">
            <div class="row">
                <?php include "header.php"; ?>

                <?php
                $invoice_rs = Database::search("SELECT * FROM `invoice_data` WHERE `users_email`='" . $email . "'");
                $invoice_num = $invoice_rs->num_rows;
                ?>

                <div class="col-12 text-center my-4">
                    <h1 class="fw-bold text-primary">Purchasing History</h1>
                </div>

                <?php if ($invoice_num == 0) { ?>
                    <div class="col-12 text-center bg-light py-5">
                        <h2 class="fw-bold text-muted">You have not purchased any item yet...</h2>
                    </div>
                <?php } else { ?>

                    <?php for ($x = 0; $x < $invoice_num; $x++) {
                        $invoice_data = $invoice_rs->fetch_assoc();
                        $invD_rs = Database::search("SELECT * FROM `invoice_product` WHERE `invoice_data_id`='" . $invoice_data["id"] . "'");
                        $invD_num = $invD_rs->num_rows;
                    ?>

                        <div class="col-12 mb-3">
                            <div class="card border-secondary">
                                <div class="card-body">
                                    <div class="row   grid gap-0 row-gap-3">
                                        <?php for ($i = 0; $i < $invD_num; $i++) {
                                            $invD_data = $invD_rs->fetch_assoc();
                                            $pid = $invD_data["product_id"];
                                            $image_rs = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $pid . "'");
                                            $image_data = $image_rs->fetch_assoc();
                                            $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $pid . "'");
                                            $product_data = $product_rs->fetch_assoc();
                                            $seller_rs = Database::search("SELECT * FROM `seller` WHERE `id`='" . $product_data["seller_id"] . "'");
                                            $seller_data = $seller_rs->fetch_assoc();
                                        ?>
                                            <div class=" col-md-4 mt-2">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <img src="<?php echo $image_data["img_path"]; ?>" class="img-fluid rounded" alt="Product Image">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <h5 class="card-title text-primary"><?php echo $invD_data["title"]; ?></h5>
                                                        <p class="mb-1">Price: Rs. <?php echo $invD_data["price"]; ?>.00</p>
                                                        <p class="mb-1">Seller: <?php echo $seller_data["fname"] . " " . $seller_data["lname"]; ?></p>
                                                        <p>Seller Mobile: <?php echo $seller_data["mobile"]; ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2 text-center my-auto ">
                                                <span class="fs-5"><?php echo $invD_data["qty"]; ?></span>
                                            </div>
                                            <div class="col-md-2 text-center my-auto ">
                                                <span class="badge bg-<?php echo $invD_data["status"] == 4 ? "success" : "warning"; ?> fs-6">
                                                    <?php
                                                    switch ($invD_data["status"]) {
                                                        case 0:
                                                            echo "Confirm Order";
                                                            break;
                                                        case 1:
                                                            echo "Packing";
                                                            break;
                                                        case 2:
                                                            echo "Dispatch";
                                                            break;
                                                        case 3:
                                                            echo "Shipping";
                                                            break;
                                                        case 4:
                                                            echo "Delivered";
                                                            break;
                                                    }
                                                    ?>
                                                </span>
                                            </div>
                                            <div class=" justify-content-center  col-lg-2 col-md-3 text-center my-auto ">
                                                <button class="btn btn-info rounded  fs-5 col-10 " onclick="addFeedback(<?php echo $pid; ?>);">
                                                    <i class="bi bi-info-circle-fill"></i> Feedback
                                                </button>
                                            </div>
                                        <?php } ?>

                                        <div class="col-lg-2 col-md-12 text-end mt-3">
                                            <p class="mb-0">Order ID: <?php echo $invoice_data["order_id"]; ?></p>
                                            <p class="mb-0">Date: <?php echo $invoice_data["date"]; ?></p>
                                            <p>Total: Rs. <?php echo $invoice_data["total"]; ?>.00</p>
                                            <button class="btn btn-danger mt-2" onclick="invoice('<?php echo $invoice_data['order_id']; ?>');">
                                                <i class="bi bi-printer-fill"></i> Print Invoice
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- model -->
                        <div class="modal fade" id="feedbackModal<?php echo $pid; ?>" tabindex="-1" aria-labelledby="feedbackModalLabel<?php echo $pid; ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title fw-bold" id="feedbackModalLabel<?php echo $pid; ?>">Add New Feedback</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">

                                        <div class="row mb-3">
                                            <div class="col-3">
                                                <label class="form-label fw-bold">User's Email</label>
                                            </div>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="mail" value="<?php echo $email; ?>" readonly />
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-3">
                                                <label class="form-label fw-bold">Feedback</label>
                                            </div>
                                            <div class="col-9">
                                                <textarea class="form-control" id="feed" rows="5" placeholder="Write your feedback here..."></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-outline-primary" onclick="saveFeedback(<?php echo $pid; ?>);">Save Feedback</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- model -->

                    <?php } ?>
                <?php } ?>

                <?php include "footer.php"; ?>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="script.js"></script>
    </body>

    </html>
<?php
} else {
    header("Location: registerForm.php");
}
?>