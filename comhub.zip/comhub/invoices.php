<?php
session_start();
require "connection.php";

if (isset($_SESSION["u"])) {
    $oid = $_GET["id"];
    $email = $_SESSION["u"]["email"];
    $total = 0;
    $subTotal = 0;
    $delivery = 0;
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Invoice | ComHub</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
        <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
        <link rel="icon" href="resourses/logo.svg">
    </head>

    <body class="bg-light">
        <?php include "header.php"; ?>
        <hr />
        <div class="col-12 btn-toolbar justify-content-end">
            <button class="btn btn-dark me-2" onclick="printInvoice();"><i class="bi bi-printer-fill"></i>
                Print</button>
            <button class="btn btn-danger me-2" onclick="printInvoice();"><i class="bi bi-filetype-pdf"></i> Export
                as PDF</button>
        </div>
        <div class="container my-5" id="page">

            <!-- Header Section -->
            <div class="row mb-4">
                <div class="col-6">
                    <img src="resourses/logo.svg" alt="Logo" class="img-fluid" style="max-width: 150px;">
                </div>
                <div class="col-6 text-end">
                    <h2 class="text-primary">ComHub</h2>
                    <p class="mb-0">Elibichchya, Sri Lanka</p>
                    <p class="mb-0">+9476 7239281</p>
                    <p class="mb-0">nimeshsayuranga31@gmail.com</p>
                </div>
            </div>
            <hr>

            <!-- Invoice Info -->
            <div class="row">
                <div class="col-md-6">
                    <h5 class="fw-bold">Invoice To:</h5>
                    <?php

                    $invoice_rs = Database::search("SELECT * FROM `invoice_data` WHERE `order_id`='" . $oid . "'");
                    $invoice_data = $invoice_rs->fetch_assoc();

                    $invoiceProduct_rs = Database::search("SELECT * FROM `invoice_product` WHERE `invoice_data_id`='" . $invoice_data["id"] . "'");
                    $invoiceProduct_num = $invoiceProduct_rs->num_rows;

                    $address_rs = Database::search("SELECT * FROM `ship_address` WHERE `invoice_data_id`='" . $invoice_data["id"] . "'");
                    $address_data = $address_rs->fetch_assoc();

                    ?>
                    <p class="mb-0"><?php echo $_SESSION["u"]["fname"] . " " . $_SESSION["u"]["lname"]; ?></p>
                    <p class="mb-0"><?php echo $_SESSION["u"]["mobile"]; ?></p>
                    <p class="mb-0"><?php echo $email; ?></p>
                </div>
                <div class="col-md-6 text-end">
                    <h4 class="text-primary">Invoice #<?php echo $invoice_data["id"]; ?></h4>
                    <p class="mb-0">Date: <?php echo $invoice_data["date"]; ?></p>
                    <p class="mb-0">Order ID: <span class="text-danger"><?php echo $oid; ?></span></p>
                </div>
            </div>
            <hr>

            <!-- Product Table -->
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead class="table-primary">
                        <tr>
                            <th>#</th>
                            <th>Product</th>
                            <th class="text-end">Unit Price</th>
                            <th class="text-end">Quantity</th>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $invoice_rs = Database::search("SELECT * FROM `invoice_data` WHERE `order_id`='" . $oid . "'");
                        $invoice_data = $invoice_rs->fetch_assoc();
                        $invoiceProduct_rs = Database::search("SELECT * FROM `invoice_product` WHERE `invoice_data_id`='" . $invoice_data["id"] . "'");
                        $invoiceProduct_num = $invoiceProduct_rs->num_rows;

                        for ($x = 0; $x < $invoiceProduct_num; $x++) {
                            $invoiceProduct_data = $invoiceProduct_rs->fetch_assoc();
                            $total = $invoiceProduct_data["price"] * $invoiceProduct_data["qty"];
                            $subTotal += $total;
                        ?>
                            <tr>
                                <td><?php echo $x + 1; ?></td>
                                <td><?php echo $invoiceProduct_data["title"]; ?></td>
                                <td class="text-end">Rs. <?php echo $invoiceProduct_data["price"]; ?>.00</td>
                                <td class="text-end"><?php echo $invoiceProduct_data["qty"]; ?></td>
                                <td class="text-end">Rs. <?php echo $total; ?>.00</td>
                            </tr>
                        <?php }
                        $delivery = $invoice_data["total"] - $subTotal;
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3"></td>
                            <td class="text-end fw-bold">Subtotal</td>
                            <td class="text-end">Rs. <?php echo $subTotal; ?>.00</td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td class="text-end fw-bold">Delivery Fee</td>
                            <td class="text-end">Rs. <?php echo $delivery; ?>.00</td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td class="text-end fw-bold text-primary">Grand Total</td>
                            <td class="text-end text-primary">Rs. <?php echo $invoice_data["total"]; ?>.00</td>
                        </tr>
                    </tfoot>
                </table>
            </div>


            <div class="alert alert-info mt-4" role="alert">
                <strong>Notice:</strong> Purchased items can be returned within 3 days of delivery.
            </div>

            <div class="text-center text-muted">
                <p class="mb-0">Invoice was created electronically and is valid without signature or seal.</p>
            </div>
        </div>
        <?php include "footer.php"; ?>
        <script src="script.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </body>

    </html>
<?php } else {
    header("Location: registerForm.php");
} ?>