<?php
session_start();
require "connection.php";
if (isset($_SESSION["au"])) {
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Seller & Shop Reports | Admins | ComHub</title>

        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
        <link rel="stylesheet" href="style.css" />
        <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
        <link rel="icon" href="resourses/logo.svg" />

    </head>

    <body class="bg">

        <div class="container-fluid">
            <div class="row">

                <div class="col-6 mt-5 d-flex justify-content-start ">
                    <button class="btn btn-dark" onclick="history.back();"><i class="bi bi-arrow-left"></i>BACK</button>
                </div>
                <div class="col-6 mt-5 d-flex justify-content-end ">
                    <button class="btn btn-danger me-2" onclick="printReport();"><i class="bi bi-printer-fill"></i> Print</button>
                </div>

                <div class="container">
                    <div class="row" id="printArea">
                        <div class="col-12 text-center mt-5">
                            <h1>Seller & Shop Reports</h1>
                        </div>
                        <div class="col-12 mt-5 table-responsive">
                            <table class="table  table-striped table-bordered ">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Seller Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Shop Name</th>
                                        <th>Shop</th>
                                        <th>Status</th>
                                        <th>Validate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $rs = Database::search("SELECT * FROM `seller` ");
                                    $num = $rs->num_rows;

                                    for ($x = 0; $x < $num; $x++) {
                                        $row = $rs->fetch_assoc();

                                        $rs1 = Database::search("SELECT * FROM `seller_details` WHERE `seller_id`='" . $row["id"] . "' ");
                                        $row1 = $rs1->fetch_assoc();

                                        $rs2 = Database::search("SELECT * FROM `shop_img` WHERE `seller_id`='" . $row["id"] . "' ");
                                        $row2 = $rs2->fetch_assoc();
                                    ?>
                                        <tr>
                                            <td><?php echo $x + 1; ?></td>
                                            <td><?php echo ($row["fname"] . " " . $row["lname"]); ?></td>
                                            <td><?php echo ($row["email"]); ?></td>
                                            <td><?php echo ($row["mobile"]); ?></td>
                                            <td>
                                                <?php

                                                if (empty($row1["shop_name"])) {
                                                ?>
                                                    Not Update Seller
                                                <?php
                                                } else {
                                                ?>
                                                    <?php echo ($row1["shop_name"]); ?>
                                                <?php
                                                }

                                                ?>
                                            </td>
                                            <td>

                                                <?php

                                                if (empty($row2["path"])) {
                                                ?>
                                                    <img src="resourses/shop.png" height="50px" width="50px" />
                                                <?php
                                                } else {
                                                ?>
                                                    <img src="<?php echo $row2["path"]; ?>" height="50px" width="50px" />
                                                <?php
                                                }

                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                if ($row["status"] == '1') {
                                                    echo ("Active");
                                                } else {
                                                    echo ("Inactive");
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php

                                                if ($row["isverfy"] == '1') {
                                                   echo ("Verify Seller");
                                                } else {

                                                    echo ("Not Verify Seller");

                                                }

                                                ?>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="fixed-bottom col-12">
                    <p class="text-center">&copy;2024 comhub.com || ALL Rights Reserved</p>
                    <p class="text-center">Designed By <b>Nimesh Sayuranga</b></p>
                </div>

            </div>
        </div>



        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
    </body>

    </html>

<?php

} else {
    header("Location: adminSignIn.php");
}

?>