<?php

session_start();

require "connection.php";

if (isset($_SESSION["user"])) {
    $email = $_SESSION["user"]["email"];
    $id = $_SESSION["user"]["id"];
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Seller Profile | ComHub</title>
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" />
        <link rel="stylesheet" href="style.css" />
        <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
        <link rel="icon" href="resourses/logo.svg" />

    </head>

    <body>

        <div class="container-fluid">
            <div class="row ">
                <?php include "sellerHeader.php";

                $seller_rs = Database::search("SELECT * FROM `seller`  WHERE `email`='" . $email . "'");
                $seller_data = $seller_rs->fetch_assoc();

                $details_rs = Database::search("SELECT * FROM `seller_details`  WHERE `seller_id`='" . $id . "'");
                $details_data = $details_rs->fetch_assoc();

                $img_rs = Database::search("SELECT * FROM `shop_img`  WHERE `seller_id`='" . $seller_data["id"] . "'");
                $img_data = $img_rs->fetch_assoc();

                ?>
                <div class="col-12 bg-primary">
                    <div class="row">

                        <div class="col-12 bg-body mt-4 mb-4">
                            <div class="row g-2">

                                <div class="col-md-3 border-end">
                                    <div class="d-flex flex-column align-items-center text-center p-3 py-5">

                                        <?php

                                        if (empty($img_data["path"])) {
                                        ?>
                                            <img src="resourses/shop.png" width="200px" height="200px" class="rounded-circle bg-secondary bg-opacity-10" />
                                        <?php
                                        } else {
                                        ?>
                                            <img src="<?php echo $img_data["path"]; ?>" width="200px" height="200px" class="rounded-circle" />
                                        <?php
                                        }

                                        ?>

                                        <br />
                                        <?php

                                        if (!empty($details_data["shop_name"])) {

                                        ?>
                                            <span class="fw-bold"><?php echo $details_data["shop_name"]; ?></span>
                                        <?php } else { ?>
                                            <span class="fw-bold"></span>
                                        <?php } ?>

                                        <input type="file" class="d-none" id="profileImage" />
                                        <label for="profileImage" class="btn btn-primary mt-5">Update Profile Image</label>

                                    </div>
                                </div>

                                <div class="col-md-5 border-end">
                                    <div class="p-3 py-5">

                                        <div class="d-flex justify-content-center align-items-center mb-3">
                                            <h4 class="fw-bold">Shop Profile Settings</h4>
                                        </div>

                                        <div class="row mt-4">

                                            <div class="mb-3 ">
                                                <hr class="border border-1 border-secondary mb-1" />
                                                <h4 class="fw-bold">Seller Details</h4>
                                                <hr class="border border-1 border-secondary mt-1" />
                                            </div>

                                            <div class="col-12  col-lg-6">
                                                <label class="form-label">First Name</label>
                                                <input type="text" id="fname" class="form-control" value="<?php echo $seller_data["fname"]; ?>" />
                                            </div>

                                            <div class="col-12  col-lg-6">
                                                <label class="form-label">Last Name</label>
                                                <input type="text" id="lname" class="form-control" value="<?php echo $seller_data["lname"]; ?>" />
                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Mobile Number</label>
                                                <input type="text" id="mobile" class="form-control" value="<?php echo $seller_data["mobile"]; ?>" />
                                            </div>

                                            <div class="col-12  col-lg-6">
                                                <label class="form-label">Email</label>
                                                <input type="text" id="email" class="form-control" value="<?php echo $seller_data["email"]; ?>" readonly />
                                            </div>

                                            <div class="col-12  col-lg-6">
                                                <label class="form-label">Password</label>
                                                <div class="input-group">
                                                    <input type="password" class="form-control" aria-describedby="basic-addon2" id="pw" value="<?php echo $seller_data["password"]; ?>" />
                                                    <button class="input-group-text" id="basic-addon2  " onclick=" changePassword();" id="pwv">
                                                        <i class="bi bi-eye"></i>
                                                    </button>
                                                </div>
                                            </div>

                                            <div class="mb-3 mt-3 col-12 ">
                                                <hr class="border border-1 border-secondary mb-1" />
                                                <h4 class="fw-bold">Shop Details</h4>
                                                <hr class="border border-1 border-secondary mt-1" />
                                            </div>

                                            <?php
                                            if (!empty($details_data["shop_name"])) {
                                            ?>
                                                <div class="col-12 col-lg-6">
                                                    <label class="form-label">Shop Name</label>
                                                    <input type="text" class="form-control" id="sname" placeholder="Your Shop Name" value="<?php echo $details_data["shop_name"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-6">
                                                    <label class="form-label">Shop Name</label>
                                                    <input type="text" id="sname" class="form-control" placeholder="Your Shop Name" />
                                                </div>
                                            <?php } ?>

                                            <?php
                                            if (!empty($details_data["register_no"])) {
                                            ?>
                                                <div class="col-12 col-lg-6">
                                                    <label class="form-label">Registered Code</label>
                                                    <input type="text" class="form-control" id="rcode" placeholder="Your Business Register Number" value="<?php echo $details_data["register_no"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-6">
                                                    <label class="form-label">Registered Code</label>
                                                    <input type="text" id="rcode" class="form-control" placeholder="Your Business Register Number" />
                                                </div>
                                            <?php } ?>

                                            <?php
                                            if (!empty($details_data["address1"])) {
                                            ?>
                                                <div class="col-12 col-lg-6">
                                                    <label class="form-label">Address Line 01</label>
                                                    <input type="text" id="line1" class="form-control" placeholder="Enter Address Line 01" value="<?php echo $details_data["address1"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-6">
                                                    <label class="form-label">Address Line 01</label>
                                                    <input type="text" id="line1" class="form-control" placeholder="Enter Address Line 01" />
                                                </div>
                                            <?php } ?>

                                            <?php
                                            if (!empty($details_data["address2"])) {
                                            ?>
                                                <div class="col-12 col-lg-6">
                                                    <label class="form-label">Address Line 02</label>
                                                    <input type="text" id="line2" class="form-control" placeholder="Enter Address Line 02" value="<?php echo $details_data["address2"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-6">
                                                    <label class="form-label">Address Line 02</label>
                                                    <input type="text" id="line2" class="form-control" placeholder="Enter Address Line 02" />
                                                </div>
                                            <?php } ?>

                                            <?php
                                            if (!empty($details_data["city"])) {
                                            ?>
                                                <div class="col-12 col-lg-12">
                                                    <label class="form-label">City</label>
                                                    <input type="text" class="form-control" id="city" placeholder="Enter Your City" value="<?php echo $details_data["city"]; ?>" />
                                                </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-12">
                                                    <label class="form-label">City</label>
                                                    <input type="text" class="form-control" id="city" placeholder="Enter Your City" />
                                                </div>
                                            <?php } ?>


                                            <div class="mb-3 mt-3 col-12 ">
                                                <hr class="border border-1 border-secondary mb-1" />
                                                <h4 class="fw-bold">Payment Details</h4>
                                                <hr class="border border-1 border-secondary mt-1" />
                                            </div>

                                            <?php
                                            if (!empty($details_data["account_holder"])) {
                                            ?>
                                                <div class="col-12 col-lg-6">
                                                <label class="form-label">Account Holder</label>
                                                <input type="text" class="form-control" id="hname" placeholder="Enter Account Holder Name" value="<?php echo $details_data["account_holder"]; ?>" />
                                            </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-6">
                                                <label class="form-label">Account Holder</label>
                                                <input type="text" class="form-control" id="hname" placeholder="Enter Account Holder Name"  />
                                            </div>
                                            <?php } ?>
                                            
                                            <?php
                                            if (!empty($details_data["account_number"])) {
                                            ?>
                                                <div class="col-12 col-lg-6">
                                                <label class="form-label">Account Number</label>
                                                <input type="text" class="form-control" id="anumber" placeholder="Your Bank Account Number" value="<?php echo $details_data["account_number"]; ?>" />
                                            </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-6">
                                                <label class="form-label">Account Number</label>
                                                <input type="text" class="form-control" id="anumber" placeholder="Your Bank Account Number"  />
                                            </div>
                                            <?php } ?>
                                            
                                            <?php
                                            if (!empty($details_data["bank"])) {
                                            ?>
                                                <div class="col-12 col-lg-6">
                                                <label class="form-label">Bank </label>
                                                <input type="text" id="bank" class="form-control" placeholder="Bank Name" value="<?php echo $details_data["bank"]; ?>" />
                                            </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-6">
                                                <label class="form-label">Bank </label>
                                                <input type="text" id="bank" class="form-control" placeholder="Bank Name"  />
                                            </div>
                                            <?php } ?>
                                            
                                            <?php
                                            if (!empty($details_data["branch"])) {
                                            ?>
                                                <div class="col-12 col-lg-6">
                                                <label class="form-label">Branch</label>
                                                <input type="text" id="branch" class="form-control" placeholder="Place of Bank Branch" value="<?php echo $details_data["branch"]; ?>" />
                                            </div>
                                            <?php } else { ?>
                                                <div class="col-12 col-lg-6">
                                                <label class="form-label">Branch</label>
                                                <input type="text" id="branch" class="form-control" placeholder="Place of Bank Branch" />
                                            </div>
                                            <?php } ?>
                                            

                                            <div class="col-12 d-grid mt-2">
                                                <button class="btn btn-primary" onclick="sellerProfile();">Update My Profile</button>
                                            </div>

                                        </div>

                                    </div>
                                </div>

                                <div class="col-md-4 ">
                                    <div class="p-3 py-5">

                                        <div class="d-flex justify-content-center align-items-center mb-3">
                                            <h4 class="fw-bold text-danger fs-1">Important</h4>
                                        </div>

                                        <h5 class="fs-4"> For this we expect that the data yoy receive is true information. And please Enter
                                            the data you enter correctly and your true status, because we will carry out future
                                            work based on the data you enter, and we need your true information for future transactions with us.
                                        </h5>

                                        <h5 class="fs-4"> At the same time, we and our working group are committed to protecting the information you provide.</h5>

                                        <h5 class="fs-4"> Thank to the founder of the ComHub business. </h5>

                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>


                <?php include "footer.php"; ?>

            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
    </body>

    </html>
<?php

} else {
    header("Location: sellerLogin.php");
}

?>