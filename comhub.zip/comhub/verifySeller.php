<?php

require "connection.php";
$code = $_GET["code"];

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Seller Verify| ComHub</title>
    <link rel="icon" href="resourses/logo.svg">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid vh-100 d-flex justify-content-center">
        <div class="row align-content-center">

            <div class="col-12 ">
                <div>
                    <h1 style="font-size: 35px; color:black; font-weight:bold;">Seller Verification</h1>
                </div>
                <button class="col-12 btn btn-primary mt-2" onclick="verify1('<?php echo ($code); ?>');">Verify</button>
            </div>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="script.js"></script>
    <script src="bootstrap.js"></script>

</body>

</html>