<?php

session_start();

require "connection.php";

$email = $_SESSION["u"]["email"];
?>

<!DOCTYPE html>
<html>

<head>
  <title> Printer | ComHub</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="style.css">
  <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
  <link rel="icon" href="resourses/logo.svg">

</head>

<body>
  <div class="container-fluid">
    <div class="row">

      <?php include "header.php"; ?>

      <!-- products -->
      <div class="col-12 mb-5 mt-5 ">
        <div class=" row  border border-primary">
          <div class="col-12">
            <div class=" row justify-content-center gap-3">

              <?php

              $product_rs = Database::search("SELECT * FROM product WHERE  `category_cat_id` = '5'");

              $product_num = $product_rs->num_rows;

              for ($x = 0; $x < $product_num; $x++) {
                $product_data = $product_rs->fetch_assoc();

              ?>

                <div class="card col-12 col-lg-2 mt-2 mb-2" style="width: 18rem;">

                  <?php

                  $img_rs = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $product_data['id'] . "'");

                  $img_data = $img_rs->fetch_assoc();

                  ?>


                  <img src="<?php echo $img_data["img_path"]; ?>" class="card-img-top img-thumbnail mt-2" style="height: 180px;" />
                  <div class="card-body ms-0 m-0 text-center">
                    <h5 class="card-title fw-bold fs-6"><?php echo $product_data["title"]; ?></h5>
                    <span class="badge rounded-pill text-bg-info">New</span><br />
                    <span class="card-text text-primary">Rs. <?php echo $product_data["price"]; ?> .00</span><br />
                    <span class="card-text text-warning fw-bold">In Stock</span><br />
                    <span class="card-text text-success fw-bold"><?php echo $product_data["qty"]; ?> Items Available</span><br />
                    <a href="<?php echo "singleproductview.php?id=" . ($product_data["id"]); ?>" class="col-12 btn btn-success">Buy Now</a>
                    <button class="col-12 btn btn-dark mt-2" onclick="addToCart(<?php echo $product_data['id']; ?>);">
                      <i class="bi bi-cart4 text-white fs-5"></i>
                    </button>
                    <button onclick="addToWatchlist(<?php echo $product_data['id']; ?>);" class="col-12 btn btn-outline-light mt-2 border border-primary">
                      <i class="bi bi-heart-fill text-dark fs-5"></i>
                    </button>
                  </div>
                </div>

              <?php

              }

              ?>
            </div>
          </div>

        </div>
      </div>

      <!-- products -->

      <?php include "footer.php" ?>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="bootstrap.bundle.js"></script>
  <script src="script.js"></script>
</body>

</html>