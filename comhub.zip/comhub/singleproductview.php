<?php
session_start();

require "connection.php";

if (isset($_SESSION["u"])) {

    $email = $_SESSION["u"]["email"];

    if (isset($_GET["id"])) {
        $pid = $_GET["id"];

        $product_rs = Database::search("SELECT product.id,product.price,product.qty,product.description,product.title,product.datetime_added,product.weight,
                                    product.category_cat_id,product.model_has_brand_id,product.color_clr_id,product.status_status_id,product.condition_condition_id,product.seller_id,model.model_name 
                                    AS mname,brand.brand_name AS bname FROM `product` INNER JOIN `model_has_brand` ON model_has_brand.id=product.model_has_brand_id INNER JOIN `brand` ON 
                                    brand.brand_id=model_has_brand.brand_brand_id INNER JOIN `model` ON model.model_id=model_has_brand.model_model_id WHERE product.id='" . $pid . "'");

        $product_num = $product_rs->num_rows;
        if ($product_num == 1) {
            $product_data = $product_rs->fetch_assoc();
        }
    }

?>

    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Single Product View | ComHub</title>
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
        <link rel="stylesheet" href="style.css" />
        <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
        <link rel="icon" href="resourses/logo.svg" />
    </head>

    <body>

        <div class="container-fluid">
            <div class="row">

                <?php include "header.php"; ?>

                <div class="col-12 border-bottom border-1 border-dark-5">
                    <label class="form-label fs-1 fw-bolder offset-lg-5  ">Single Product View </label>
                </div>

                <div class="col-12 " style="padding: 10px;">
                    <div class="row">
                        <div class="col-12 col-lg-12 border-bottom border-1 border-dark mb-3 ">
                            <div class="row">
                                <div class="col-6 col-lg-12 ">
                                    <div class="row d-block me-0 mt-2  ">
                                        <div class="col-12 ">
                                            <span class="fs-3  fw-bold">Product Details</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-6 mt-0 bg-white singleProduct ">
                    <div class="row">

                        <div class="col-12 col-lg-4 order-2 order-lg-1">
                            <ul>

                                <?php
                                $image_rs = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $pid . "'");
                                $image_num = $image_rs->num_rows;
                                $img = array();

                                if ($image_num != 0) {

                                    for ($x = 0; $x < $image_num; $x++) {
                                        $image_data = $image_rs->fetch_assoc();
                                        $img[$x] = $image_data["img_path"];
                                ?>
                                        <li class="d-flex flex-column justify-content-center align-items-center 
                                            border border-1 border-secondary mb-1">
                                            <img src="<?php echo $img[$x]; ?>" class="img-thumbnail mt-1 mb-1" style="height: 200px;" id="productImg<?php echo $x; ?>" onclick="loadMainImg(<?php echo $x; ?>);" />
                                        </li>
                                    <?php
                                    }
                                } else {
                                    ?>
                                    <li class="d-flex flex-column justify-content-center align-items-center 
                                            border border-1 border-secondary mb-1">
                                        <img src="resourses/empty.svg" class="img-thumbnail mt-1 mb-1" />
                                    </li>
                                    <li class="d-flex flex-column justify-content-center align-items-center 
                                            border border-1 border-secondary mb-1">
                                        <img src="resourses/empty.svg" class="img-thumbnail mt-1 mb-1" />
                                    </li>
                                    <li class="d-flex flex-column justify-content-center align-items-center 
                                            border border-1 border-secondary mb-1">
                                        <img src="resourses/empty.svg" class="img-thumbnail mt-1 mb-1" />
                                    </li>
                                <?php } ?>

                            </ul>
                        </div>

                        <div class="col-lg-8 col-12 order-2 order-lg-1 d-none d-lg-block">
                            <div class="row">
                                <div class="col-12 align-items-center border border-1  border-secondary">
                                    <div class="mainImg" id="mainImg"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-6 mt-5 bg-white ">
                    <div class="row">
                        <?php
                        $brand_rs = Database::search("SELECT * FROM `brand` WHERE `brand_id` IN 
                                                                (SELECT `brand_brand_id` FROM `model_has_brand` WHERE 
                                                                `id`='" . $product_data["model_has_brand_id"] . "')");
                        $brand_data = $brand_rs->fetch_assoc();
                        ?>
                        <div class="col-6">
                            <div class="row">
                                <div class="col-3">
                                    <label class="form-label fs-4 fw-bold">Brand: </label>
                                </div>
                                <div class="col-9">
                                    <label class="form-label fs-4"><?php echo $brand_data["brand_name"]; ?></label>
                                </div>
                            </div>
                        </div>
                        <?php
                        $model_rs = Database::search("SELECT * FROM `model` WHERE `model_id` IN 
                                                                    (SELECT `model_model_id` FROM `model_has_brand` WHERE 
                                                                    `id`='" . $product_data["model_has_brand_id"] . "')");
                        $model_data = $model_rs->fetch_assoc();
                        ?>
                        <div class="col-6">
                            <div class="row">
                                <div class="col-3">
                                    <label class="form-label fs-4 fw-bold">Model: </label>
                                </div>
                                <div class="col-9">
                                    <label class="form-label fs-4"><?php echo $model_data["model_name"]; ?></label>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="row">
                                <div class="col-12">
                                    <label class="form-label fs-4 fw-bold">Description: </label>
                                </div>
                                <div class="col-12">
                                    <textarea cols="60" rows="17" class="form-control" readonly><?php echo $product_data["description"]; ?></textarea>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-12 border-bottom border-1 border-dark-5 "></div>

                <div class="col-12">
                    <div class="row">

                        <div class="col-12 col-lg-6 ">
                            <div class="row">
                                <div class="col-12 col-lg-12 order-3 border-end border-dark-5">
                                    <div class="row">
                                        <div class="col-12">

                                            <div class="row border-bottom border-dark">
                                                <nav aria-label="breadcrumb">
                                                    <ol class="breadcrumb">
                                                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                                        <li class="breadcrumb-item active" aria-current="page">Single Product View</li>
                                                    </ol>
                                                </nav>
                                            </div>
                                            <div class="row border-bottom border-dark">
                                                <div class="col-12 my-2">
                                                    <span class="fs-4 fw-bold text-success"><?php echo $product_data["title"]; ?></span>
                                                </div>
                                            </div>
                                            <div class="row border-bottom border-dark">
                                                <div class="col-12 my-2">
                                                    <span class="badge">
                                                        <i class="bi bi-star-fill text-warning fs-5"></i>
                                                        <i class="bi bi-star-fill text-warning fs-5"></i>
                                                        <i class="bi bi-star-fill text-warning fs-5"></i>
                                                        <i class="bi bi-star-fill text-warning fs-5"></i>
                                                        <i class="bi bi-star-fill text-warning fs-5"></i>

                                                        &nbsp;&nbsp;&nbsp;

                                                        <label class="fs-5 text-dark fw-bold">4.5 Stars | 39 Reviews and Ratings</label>
                                                    </span>
                                                </div>
                                            </div>

                                            <?php
                                            $price = $product_data["price"];
                                            $adding_price = ($price / 100) * 10;
                                            $new_price = $price + $adding_price;
                                            $difference = $new_price - $price;
                                            $percentage = ($difference / $price) * 100;

                                            $seller_rs = Database::search("SELECT * FROM `seller` WHERE `id`='" . $product_data["seller_id"] . "'");
                                            $seller_data = $seller_rs->fetch_assoc();

                                            ?>

                                            <div class="row border-bottom border-dark">
                                                <div class="col-12 my-2">
                                                    <span class="fs-4 text-dark fw-bold">Rs. <?php echo $price; ?> .00</span>
                                                    &nbsp;&nbsp; | &nbsp;&nbsp;
                                                    <span class="fs-4 text-danger fw-bold"><del> Rs. <?php echo $new_price; ?> .00 </del></span>
                                                    &nbsp;&nbsp; | &nbsp;&nbsp;
                                                    <span class="fs-4 fw-bold text-black-50">Save Rs. <?php echo $difference; ?>.00 (Discount)</span>
                                                </div>
                                            </div>

                                            <div class="row border-bottom border-dark">
                                                <div class="col-12 my-2">
                                                    <span class="fs-5 text-primary"><b>Seller : </b><?php echo $seller_data["fname"]. " " . $seller_data["lname"]; ?></span><br />
                                                    <span class="fs-5 text-primary"><b>In Stock : </b><?php echo $product_data["qty"]; ?></span>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="row">
                                                        <div class="my-2 offset-lg-2 col-12 col-lg-8 border border-2 border-danger rounded">
                                                            <div class="row">
                                                                <div class="col-3 col-lg-2 border-end border-2 border-danger">
                                                                    <img src="resourses/pricetag.png" />
                                                                </div>
                                                                <div class="col-9 col-lg-10">
                                                                    <span class="fs-5 text-danger fw-bold">
                                                                        Stand a chance to get 5% discount by using VISA or MASTER
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="row">
                                                        <div class="col-12 my-2">
                                                            <div class="row g-2">
                                                                <div class="border border-1 border-secondary rounded overflow-hidden 
                                                                        float-left mt-1 position-relative product-qty">
                                                                    <div class="col-12">
                                                                        <span>Quantity : </span>
                                                                        <input type="text" class="border-0 fs-5 fw-bold text-start" style="outline: none;" pattern="[0-9]" value="1" 
                                                                        onkeyup='check_value(<?php echo $product_data["qty"]; ?>);' id="qty_input" />
                                                                        <div class="position-absolute qty-buttons">
                                                                            <div class="justify-content-center d-flex flex-column align-items-center 
                                                                         border border-1 border-secondary qty-inc">
                                                                                <i class="bi bi-caret-up-fill text-primary fs-4" onclick='qty_inc(<?php echo $product_data["qty"]; ?>);'></i>
                                                                            </div>
                                                                            <div class="justify-content-center d-flex flex-column align-items-center 
                                                                            border border-1 border-secondary qty-dec">
                                                                                <i class="bi bi-caret-down-fill text-primary fs-4" onclick='qty_dec();'></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-12 mt-5">
                                                                        <div class="row">
                                                                            <div class="col-4 d-grid">
                                                                                <button class="btn btn-success" type="submit" id="payhere-payment" onclick="payNow(<?php echo $pid ?>);">Pay Now</button>
                                                                            </div>
                                                                            <div class="col-4 d-grid">
                                                                                <button class="btn btn-primary" onclick='addToCart(<?php echo $product_data["id"]; ?>);'>Add To Cart</button>
                                                                            </div>
                                                                            <div class="col-4 d-grid">
                                                                                <button class="btn btn-secondary" onclick='addToWatchlist(<?php echo $product_data["id"]; ?>); '>
                                                                                    <i class="bi bi-heart-fill fs-4 text-danger"></i>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-lg-5   ">
                            <div class="row"> 

                                <div class="col-12 offset-lg-1">
                                    <div class="row">

                                        <div class="col-12">
                                            <div class="row d-block me-0 mt-4 mb-3 border-bottom  border-1 border-dark">
                                                <div class="col-12">
                                                    <span class="fs-4 fw-bold">Feedbacks</span>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-12 border border-1 border-dark rounded offset-lg-1" style="height: 50vh;">
                                    <div class="row  overflow-scroll me-0  justify-content-center" >

                                        <?php
                                        $feed_rs = Database::search("SELECT * FROM `feedback` WHERE `product_id`='" . $pid . "'");
                                        $feed_num = $feed_rs->num_rows;

                                        

                                        for ($x = 0; $x < $feed_num; $x++) {
                                            $feed_data = $feed_rs->fetch_assoc();
                                            
                                            $fuser_rs = Database::search("SELECT * FROM `users` WHERE `email`='" . $feed_data["users_email"] . "'");
                                            $fuser_data = $fuser_rs->fetch_assoc();
                                        ?>
                                            <div class="col-11">
                                                <div class="row mt-2  border border-1 border-dark rounded mb-2">

                                                    <div class="col-10 "><?php echo $fuser_data["fname"]; ?> <?php echo $fuser_data["lname"]; ?></div>

                                                    <?php if (($feed_data["type"] == 1)) { ?>
                                                        <div class="col-2">
                                                            <span class="badge bg-success">Positive</span>
                                                        </div>

                                                    <?php } else if (($feed_data["type"] == 2)) { ?>
                                                        <div class="col-2">
                                                            <span class="badge bg-warning">Neutral</span>
                                                        </div>
                                                    <?php } else if (($feed_data["type"] == 3)) { ?>
                                                        <div class="col-2">
                                                            <span class="badge bg-danger">Negative</span>
                                                        </div>
                                                    <?php
                                                    }
                                                    ?>

                                                    <div class="col-12">
                                                        <b>
                                                            <?php echo $feed_data["feedback"]; ?>
                                                        </b>
                                                    </div>
                                                    <div class="offset-6 col-6 text-end">
                                                        <label class="form-label fs-6 text-black-50"><?php echo $feed_data["date"]; ?> </label>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-12 border-bottom border-1 border-dark-5 mt-2"></div>

                <div class="col-12 bg-white">
                    <div class="row d-block me-0 mt-4 mb-3 border-bottom border-1 border-dark">
                        <div class="col-12">
                            <span class="fs-3 fw-bold">Related Items</span>
                        </div>
                    </div>
                </div>

                <div class="col-12 bg-white">
                    <div class="row g-2">
                        <div class="offset-1 offset-lg-0 col-4 col-lg-2">
                            <?php
                            $related_rs = Database::search("SELECT * FROM `product` WHERE `model_has_brand_id`='" . $product_data["model_has_brand_id"] . "' LIMIT 4 ");
                            $related_num = $related_rs->num_rows;

                            for ($x = 0; $x < $related_num; $x++) {
                                $related_data = $related_rs->fetch_assoc();
                            }
                            ?>
                            <div class="card" style="width: 18rem;">
                                <img src="<?php echo $image_data["img_path"]; ?>" class="card-img-top" />
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $related_data["title"]; ?></h5>
                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    <a href="#" class="btn btn-primary">Go somewhere</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <?php include "footer.php"; ?>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="bootstrap.bundle.js"></script>
        <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>
        <script src="script.js"></script>

    </body>

    </html>
<?php

} else {
    header("Location: registerForm.php");
}

?>