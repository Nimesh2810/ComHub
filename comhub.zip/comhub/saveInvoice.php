<?php

session_start();
require "connection.php";

if (isset($_SESSION["u"])) {

    $email =  $_SESSION["u"]["email"];
    $order_id = $_POST["o"];
    $pid = $_POST["i"];
    $qty = $_POST["q"];
    $total = 0;
    $shipping = 0;
    $delivery  = 0;

    $d = new DateTime();
    $tz = new DateTimeZone("Asia/Colombo");
    $d->setTimezone($tz);
    $date = $d->format("Y-m-d H:i:s");

    $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $pid . "'");
    $product_data = $product_rs->fetch_assoc();

    $title = $product_data["title"];
    $price = $product_data["price"];
    $seller = $product_data["seller_id"];


    $w = $product_data["weight"] * $qty;
    $fw = ceil($w);

    if ($fw <= 1) {
        $shipping = $fw * 350;
    } else {
        $pwe = $fw - 1;
        $fwe = ceil($pwe);
        $shipping = ($fwe * 180) + 350;
    }
    $delivery = $delivery + $shipping;
    $total = ((int)$product_data["price"] * (int)$qty) + (int)$delivery;

    Database::iud("INSERT INTO `invoice_data`(`order_id`,`date`,`total`,`users_email`) VALUES 
    ('" . $order_id . "','" . $date . "','" . $total . "','" . $email . "')");

    $invD_rs = Database::search("SELECT * FROM `invoice_data` WHERE `order_id`='" . $order_id . "'");
    $invD_Data = $invD_rs->fetch_assoc();
    $id = $invD_Data["id"];
    


    Database::iud("INSERT INTO `invoice_product`(`title`,`qty`,`price`,`invoice_data_id`,`product_id`,`seller_id`) VALUES
     ('" . $title . "','" . $qty . "','" . $price . "','" . $id . "','" . $pid . "','" . $seller . "')");

    $current_qty = $product_data["qty"];
    $new_qty = $current_qty - $qty;
    Database::iud("UPDATE `product` SET `qty`='" . $new_qty . "' WHERE `id`='" . $pid . "'");

    $address_rs = Database::search("SELECT * FROM users_address WHERE `users_email`='" . $email . "'");
    $address_data = $address_rs->fetch_assoc();

    $line1 = $address_data["line1"];
    $line2 = $address_data["line2"];
    $city = $address_data["city"];
    $code = $address_data["postal_code"];


    Database::iud("INSERT INTO `ship_address`(`line1`,`line2`,`city`,`postal_code`,`invoice_data_id`) VALUES 
    ('" . $line1 . "','" . $line2 . "','" . $city . "','" . $code . "','" . $id . "')");

    echo ("1");
}
