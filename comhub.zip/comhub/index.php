<?php

session_start();

require "connection.php";


?>

<!DOCTYPE html>

<html>

<head>

  <title>Home | ComHub</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="style.css">
  <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
  <link rel="icon" href="resourses/logo.svg">
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
</head>

<body>

  <div class="container-fluid">
    <div class="row">

      <?php include "header.php"; ?>

      <hr />

      <div class="col-12 justify-content-center">
        <div class="row mb-3">

          <div class="offset-4 offset-lg-1 col-4 col-lg-1 logo" style="height: 60px;"></div>

          <div class="col-12 col-lg-6">

            <div class="input-group mb-3 mt-3">
              <input type="text" id="kw" class="form-control" aria-label="Text input with dropdown button">
              <select class="form-select" style="max-width: 250px;" id="c">
                <option value="0">All Categories</option>

                <?php

                $categry_rs = Database::search("SELECT*FROM `category`");
                $categry_num = $categry_rs->num_rows;

                for ($x = 0; $x < $categry_num; $x++) {

                  $categry_data = $categry_rs->fetch_assoc();

                ?>

                  <option value="<?php echo $categry_data["cat_id"]; ?> "> <?php echo $categry_data["cat_name"] ?>

                  </option>

                <?php

                }

                ?>

              </select>
            </div>

          </div>

          <div class="col-12 col-lg-2 d-grid">
            <button class="btn btn-primary mt-3 mb-3" onclick="basicSearch(0);">Search</button>
          </div>

          <div class="col-12 col-lg-2 mt-2 mt-lg-4 text-center text-lg-start">
            <a href="advancedSearch.php" class="text-decoration-none link-secondary fw-bold">Advanced</a>
          </div>

        </div>
      </div>

      <hr />

      <div class="col- container-fluid " id="basicSearchResult">
        <div class="row">

          <!-- Multi Carousel -->
          <div class=" col-12 fw-bold">
            <h1> All product</h1>
          </div>
          <div class="row ">
            <div class="MultiCarousel" data-items="1,3,5,6" data-slide="1" id="MultiCarousel" data-interval="1000">
              <div class="MultiCarousel-inner">
                <?php
                $p_rs = Database::search("SELECT*FROM `product`");
                $p_num = $p_rs->num_rows;
                for ($i = 0; $i < $p_num; $i++) {
                  $p_data = $p_rs->fetch_assoc();

                  $i_rs = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $p_data['id'] . "'");
                  $i_data = $i_rs->fetch_assoc();
                ?>
                  <div class="item">
                    <div class="pad18 position-relative">
                      <img src="<?php echo $i_data["img_path"]; ?>" alt="img" width="80px" height="80px">
                      <button class="rounded-circle position-absolute top-0 start-0" width="40px" height="40px" onclick="addToCart(<?php echo $p_data['id']; ?>);">
                        <i class="fs-3 bi bi-cart-plus"></i>
                      </button>
                      <p><?php echo $p_data["title"]; ?></p>
                    </div>
                  </div>
                <?php } ?>
              </div>
              <button class="btn btn-primary leftLst">
                < </button>
                  <button class="btn btn-primary rightLst"> > </button>
            </div>
          </div>
          <hr />
          <!-- Multi Carousel -->

          <?php
          $c_rs = Database::search("SELECT*FROM `category`");
          $c_num = $c_rs->num_rows;

          for ($y = 0; $y < $categry_num; $y++) {

            $c_data = $c_rs->fetch_assoc();

            $li_rs = Database::search("SELECT * FROM `link`  WHERE `category_cat_id`='" . $c_data['cat_id'] . "' ");
            $li_num = $li_rs->num_rows;


            $li_data = $li_rs->fetch_assoc();

          ?>


            <div class="col-12 col-lg-6 ">
              <div class=" row">
                <!-- category names -->
                <div class="col-12 mt-3  mb-3">
                  <a href="<?php echo $li_data["link"]; ?>" class="text-decoration-none text-dark fs-3  fw-bold "><?php echo $c_data["cat_name"]; ?> </a>&nbsp;&nbsp;
                  <a href="<?php echo $li_data["link"]; ?>" class="text-decoration-none text-dark fs-6 fw-bold">See All &nbsp;&rarr;</a>
                </div>
                <!-- category names -->
                <!-- products -->
                <div class="col-12 mb-3 ">
                  <div class=" row  border border-primary">
                    <div class="col-12">
                      <div class=" row justify-content-center gap-3">

                        <?php

                        $product_rs = Database::search("SELECT * FROM `product` WHERE `category_cat_id`='" . $c_data['cat_id'] . "' 
                        AND `status_status_id`='1' ORDER BY `datetime_added` DESC LIMIT 2 OFFSET 0");

                        $product_num = $product_rs->num_rows;

                        for ($x = 0; $x < $product_num; $x++) {
                          $product_data = $product_rs->fetch_assoc();

                        ?>

                          <div class="card col-12 col-lg-2 mt-2 mb-2" style="width: 18rem;">

                            <?php

                            $img_rs = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $product_data['id'] . "'");

                            $img_data = $img_rs->fetch_assoc();

                            ?>

                            <img src="<?php echo $img_data["img_path"]; ?>" class="card-img-top img-thumbnail mt-2" style="height: 180px;" />
                            <div class="card-body ms-0 m-0 text-center">
                              <span class="card-text text-primary">Rs. <?php echo $product_data["price"]; ?> .00</span><br />
                              <span class="card-text text-warning fw-bold">In Stock</span><br />
                              <span class="card-text text-success fw-bold"><?php echo $product_data["qty"]; ?> Items Available</span><br />
                              <a href="<?php echo "singleproductview.php?id=" . ($product_data["id"]); ?>" class="col-12 btn btn-success">Buy Now</a>
                              <button class="col-12 btn btn-dark mt-2" onclick="addToCart(<?php echo $product_data['id']; ?>);">
                                <i class="bi bi-cart4 text-white fs-5"></i>
                              </button>
                              <button onclick="addToWatchlist(<?php echo $product_data['id']; ?>);" class="col-12 btn btn-outline-light mt-2 border border-primary">
                                <i id="heart" class="bi bi-heart-fill text-dark fs-5"></i>
                              </button>
                            </div>
                          </div>

                        <?php

                        }

                        ?>
                      </div>
                    </div>

                  </div>
                </div>

                <!-- products -->
              </div>
            </div>
          <?php

          }

          ?>
          <hr />
          <!-- Multi Carousel -->
          <div class=" col-12 fw-bold">
            <h1> All Categories</h1>
          </div>
          <div class="row ">
            <div class="MultiCarousel" data-items="1,3,5,6" data-slide="1" id="MultiCarousel" data-interval="1000">
              <div class="MultiCarousel-inner">
                <div class="item">
                  <div class="pad18">
                    <img src="resourses/desktop.jpg" alt="img" width="80px" height="80px">
                    <p><a href="desktop.php" class="text-decoration-none text-dark fs-3  fw-bold ">Desktop </a>&nbsp;&nbsp;</p>
                  </div>
                </div>
                <div class="item">
                  <div class="pad18">
                    <a href="laptop.php"><img src="resourses/laptop.jpg" alt="img" width="80px" height="80px"></a>
                    <p><a href="laptop.php" class="text-decoration-none text-dark fs-3  fw-bold ">Laptop </a>&nbsp;&nbsp;</p>
                  </div>
                </div>
                <div class="item">
                  <div class="pad18">
                    <a href="cammera.php"><img src="resourses/cammera.jpg" alt="img" width="80px" height="80px"></a>
                    <p><a href="cammera.php" class="text-decoration-none text-dark fs-3  fw-bold ">Camera</a>&nbsp;&nbsp;</p>
                  </div>
                </div>
                <div class="item">
                  <div class="pad18">
                    <a href="ups.php"><img src="resourses/ups-removebg-preview.png" alt="img" width="80px" height="80px"></a>
                    <p><a href="ups.php" class="text-decoration-none text-dark fs-3  fw-bold "> Ups</a>&nbsp;&nbsp;</p>
                  </div>
                </div>
                <div class="item">
                  <div class="pad18">
                    <a href="printer.php"><img src="resourses/printer.png" alt="img" width="80px" height="80px"></a>
                    <p><a href="printer.php" class="text-decoration-none text-dark fs-3  fw-bold ">Printer </a>&nbsp;&nbsp;</p>
                  </div>
                </div>
                <div class="item">
                  <div class="pad18">
                    <a href="desktop_accessories.php"><img src="resourses/PC-Accessories.webp" alt="img" width="80px" height="80px"></a>
                    <p><a href="desktop_accessories.php" class="text-decoration-none text-dark fs-3  fw-bold ">Desktop Accessories</a>&nbsp;&nbsp;</p>
                  </div>
                </div>
                <div class="item">
                  <div class="pad18">
                    <a href="laptop_accessories.php"><img src="resourses/laptopAss.png" alt="img" width="80px" height="80px"></a>
                    <p><a href="laptop_accessories.php" class="text-decoration-none text-dark fs-3  fw-bold ">Laptop Accessories </a>&nbsp;&nbsp;</p>
                  </div>
                </div>
                <div class="item">
                  <div class="pad18">
                    <a href="monitor.php"><img src="resourses/monitor.png" alt="img" width="80px" height="80px"></a>
                    <p><a href="monitor.php" class="text-decoration-none text-dark fs-3  fw-bold ">Monitor</a>&nbsp;&nbsp;</p>
                  </div>
                </div>

              </div>
              <button class="btn btn-primary leftLst">
                < </button>
                  <button class="btn btn-primary rightLst"> > </button>
            </div>
          </div>
          <!-- Multi Carousel -->

        </div>
      </div>


      <?php include "footer.php"; ?>

    </div>
  </div>
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="bootstrap.bundle.js"></script>
  <script src="script.js"></script>

</body>

</html>