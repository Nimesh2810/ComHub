<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login| ComHub</title>
    <link rel="icon" href="resourses/logo.svg">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
</head>

<body class="bg">
    <div class="container-fluid vh-100 d-flex justify-content-center">
        <div class="row ">

            <div class="col-12 ">
                <div class="row">

                    <div class="col-9 col-lg-9 d-none d-lg-block">
                        <div class="overlay-container2 vh-100 "></div>
                    </div>

                    <div class="col-10 col-lg-3 vh-100 w-full mx-auto p-2 ">

                        <div class="col-12 p-5">
                            <div class="row">

                                <div class="col-12  d-block">
                                    <div class="row g-3">

                                        <div class="col-12  mt-5">
                                            <p class="tittle02 fs-3 text-center font-bold">Sign In to your Account</p>
                                        </div>

                                        <div class="col-12">
                                            <label class="form-label">Email</label>
                                            <input type="email" class="form-control" placeholder="ex : john@gmail.com" id="e" />
                                        </div>
                                        <div class="col-12 d-grid">
                                            <button class="btn btn-danger" onclick="adminVerification();">Send Verification Code</button>
                                        </div>
                                        <br>
                                        <div class="col-12  d-grid ">
                                            <a class="link-secondary fs-6 text-decoration-none" href="index.php"> &larr; Back to Customer Log In</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--  -->

                        <div class="modal" tabindex="-1" id="verificationModal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Admin Verification</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <label class="form-label">Enter Your Verification Code</label>
                                        <input type="text" class="form-control" id="vcode">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary" onclick="verify();">Verify</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--  -->

                    </div>

                </div>
            </div>

            <!-- footer -->
            <div class="col-12  d-lg-block ">
                <p class="text-center ">&copy;2024 ComHub.com || ALL Rights Reserved</p>
            </div>
            <!--footer -->


        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="script.js"></script>
    <script src="bootstrap.js"></script>

</body>

</html>